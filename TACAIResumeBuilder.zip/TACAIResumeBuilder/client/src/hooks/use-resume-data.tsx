import { useState, useEffect, useCallback } from 'react';
import { type ResumeData } from '@shared/schema';
import { resumeStorage } from '@/lib/resume-storage';
import { useToast } from '@/hooks/use-toast';

const initialResumeData: ResumeData = {
  personalInfo: {
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    title: '',
    summary: '',
    location: '',
    linkedin: '',
    website: '',
  },
  experience: [],
  education: [],
  skills: [],
  template: 'modern',
};

export function useResumeData() {
  const [resumeData, setResumeData] = useState<ResumeData>(initialResumeData);
  const [isLoading, setIsLoading] = useState(true);
  const [lastSaved, setLastSaved] = useState<string | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const { toast } = useToast();

  // Load data on mount
  useEffect(() => {
    loadData();
  }, []);

  // Auto-save functionality
  useEffect(() => {
    if (!isLoading && hasUnsavedChanges) {
      const timeoutId = setTimeout(() => {
        autoSaveData();
      }, 2000); // Auto-save after 2 seconds of inactivity

      return () => clearTimeout(timeoutId);
    }
  }, [resumeData, hasUnsavedChanges, isLoading]);

  // Save data before page unload
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (hasUnsavedChanges) {
        const message = 'You have unsaved changes. Are you sure you want to leave?';
        e.returnValue = message;
        return message;
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [hasUnsavedChanges]);

  const loadData = useCallback(async () => {
    try {
      setIsLoading(true);
      
      // Try to load saved data first
      const savedData = resumeStorage.load();
      if (savedData) {
        setResumeData(savedData);
        setLastSaved(resumeStorage.getLastModified());
      } else {
        // Check for auto-saved data
        const autoSavedData = resumeStorage.loadAutoSave();
        if (autoSavedData) {
          setResumeData(prev => ({ ...prev, ...autoSavedData }));
          setHasUnsavedChanges(true);
          toast({
            title: 'Auto-saved data found',
            description: 'We found some unsaved changes from your last session.',
          });
        }
      }
    } catch (error) {
      console.error('Failed to load resume data:', error);
      toast({
        title: 'Failed to load data',
        description: 'There was an error loading your resume data. Starting fresh.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  const updateResumeData = useCallback((updates: Partial<ResumeData>) => {
    setResumeData(prev => {
      const newData = { ...prev, ...updates };
      
      // Deep merge for nested objects
      if (updates.personalInfo) {
        newData.personalInfo = { ...prev.personalInfo, ...updates.personalInfo };
      }
      
      return newData;
    });
    setHasUnsavedChanges(true);
  }, []);

  const saveToStorage = useCallback(async () => {
    try {
      const success = resumeStorage.save(resumeData);
      if (success) {
        setHasUnsavedChanges(false);
        setLastSaved(new Date().toISOString());
        resumeStorage.clearAutoSave();
        return true;
      } else {
        throw new Error('Save operation failed');
      }
    } catch (error) {
      console.error('Failed to save resume data:', error);
      toast({
        title: 'Save failed',
        description: 'Unable to save your resume data. Please try again.',
        variant: 'destructive',
      });
      return false;
    }
  }, [resumeData, toast]);

  const autoSaveData = useCallback(() => {
    try {
      resumeStorage.autoSave(resumeData);
    } catch (error) {
      console.error('Auto-save failed:', error);
    }
  }, [resumeData]);

  const exportData = useCallback(async () => {
    try {
      resumeStorage.export(resumeData);
      toast({
        title: 'Data exported',
        description: 'Your resume data has been exported as JSON.',
      });
    } catch (error) {
      toast({
        title: 'Export failed',
        description: 'Unable to export resume data.',
        variant: 'destructive',
      });
    }
  }, [resumeData, toast]);

  const importData = useCallback(async (file: File) => {
    try {
      const importedData = await resumeStorage.import(file);
      setResumeData(importedData);
      setHasUnsavedChanges(true);
      toast({
        title: 'Data imported',
        description: 'Your resume data has been imported successfully.',
      });
      return true;
    } catch (error) {
      toast({
        title: 'Import failed',
        description: 'Unable to import resume data. Please check the file format.',
        variant: 'destructive',
      });
      return false;
    }
  }, [toast]);

  const clearData = useCallback(() => {
    setResumeData(initialResumeData);
    resumeStorage.clear();
    setHasUnsavedChanges(false);
    setLastSaved(null);
    toast({
      title: 'Data cleared',
      description: 'All resume data has been cleared.',
    });
  }, [toast]);

  const createBackup = useCallback(() => {
    try {
      const backupData = resumeStorage.createBackup();
      if (backupData) {
        const blob = new Blob([backupData], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `resume_backup_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        toast({
          title: 'Backup created',
          description: 'Your resume backup has been downloaded.',
        });
      }
    } catch (error) {
      toast({
        title: 'Backup failed',
        description: 'Unable to create backup.',
        variant: 'destructive',
      });
    }
  }, [toast]);

  const restoreFromBackup = useCallback(async (file: File) => {
    try {
      const reader = new FileReader();
      return new Promise<boolean>((resolve) => {
        reader.onload = (e) => {
          try {
            const backupData = e.target?.result as string;
            const success = resumeStorage.restoreFromBackup(backupData);
            if (success) {
              loadData();
              toast({
                title: 'Backup restored',
                description: 'Your resume has been restored from backup.',
              });
              resolve(true);
            } else {
              throw new Error('Restore failed');
            }
          } catch (error) {
            toast({
              title: 'Restore failed',
              description: 'Unable to restore from backup file.',
              variant: 'destructive',
            });
            resolve(false);
          }
        };
        reader.readAsText(file);
      });
    } catch (error) {
      toast({
        title: 'Restore failed',
        description: 'Unable to restore from backup.',
        variant: 'destructive',
      });
      return false;
    }
  }, [loadData, toast]);

  const getStorageInfo = useCallback(() => {
    return resumeStorage.getStorageInfo();
  }, []);

  // Validation helpers
  const validateSection = useCallback((section: keyof ResumeData): boolean => {
    switch (section) {
      case 'personalInfo':
        return !!(
          resumeData.personalInfo?.firstName &&
          resumeData.personalInfo?.lastName &&
          resumeData.personalInfo?.email &&
          resumeData.personalInfo?.title
        );
      case 'experience':
        return resumeData.experience.length > 0;
      case 'education':
        return resumeData.education.length > 0;
      case 'skills':
        return resumeData.skills.length > 0;
      default:
        return true;
    }
  }, [resumeData]);

  const getCompletionPercentage = useCallback((): number => {
    const sections = ['personalInfo', 'experience', 'education', 'skills'] as const;
    const completedSections = sections.filter(section => validateSection(section)).length;
    return Math.round((completedSections / sections.length) * 100);
  }, [validateSection]);

  return {
    // Data
    resumeData,
    isLoading,
    lastSaved,
    hasUnsavedChanges,
    
    // Actions
    updateResumeData,
    saveToStorage,
    loadData,
    exportData,
    importData,
    clearData,
    createBackup,
    restoreFromBackup,
    
    // Utilities
    validateSection,
    getCompletionPercentage,
    getStorageInfo,
  };
}

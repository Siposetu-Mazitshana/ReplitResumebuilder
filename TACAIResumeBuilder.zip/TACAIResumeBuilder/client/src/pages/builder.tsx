import { useState, useEffect } from "react";
import { useResumeData } from "@/hooks/use-resume-data";
import Header from "@/components/layout/header";
import PersonalInfoForm from "@/components/resume-builder/personal-info-form";
import ExperienceForm from "@/components/resume-builder/experience-form";
import EducationForm from "@/components/resume-builder/education-form";
import SkillsForm from "@/components/resume-builder/skills-form";
import ResumePreview from "@/components/resume-builder/resume-preview";
import AISuggestions from "@/components/resume-builder/ai-suggestions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, ArrowLeft, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const STEPS = [
  { id: 1, name: "Personal Info", key: "personalInfo" },
  { id: 2, name: "Experience", key: "experience" },
  { id: 3, name: "Education", key: "education" },
  { id: 4, name: "Skills", key: "skills" },
  { id: 5, name: "Review", key: "review" },
];

export default function Builder() {
  const [currentStep, setCurrentStep] = useState(1);
  const { resumeData, updateResumeData, saveToStorage } = useResumeData();
  const { toast } = useToast();

  const progressPercentage = (currentStep / STEPS.length) * 100;

  const handleNext = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep(currentStep + 1);
      saveToStorage();
      toast({
        title: "Progress saved",
        description: "Your resume data has been saved locally.",
      });
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const isStepValid = (step: number): boolean => {
    switch (step) {
      case 1:
        return !!(resumeData.personalInfo?.firstName && 
                 resumeData.personalInfo?.lastName && 
                 resumeData.personalInfo?.email && 
                 resumeData.personalInfo?.title);
      case 2:
        return resumeData.experience.length > 0;
      case 3:
        return resumeData.education.length > 0;
      case 4:
        return resumeData.skills.length > 0;
      default:
        return true;
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return <PersonalInfoForm data={resumeData.personalInfo} onChange={(data) => updateResumeData({ personalInfo: data })} />;
      case 2:
        return <ExperienceForm data={resumeData.experience} onChange={(data) => updateResumeData({ experience: data })} />;
      case 3:
        return <EducationForm data={resumeData.education} onChange={(data) => updateResumeData({ education: data })} />;
      case 4:
        return <SkillsForm data={resumeData.skills} onChange={(data) => updateResumeData({ skills: data })} />;
      case 5:
        return (
          <div className="text-center py-12">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-4">Resume Complete!</h2>
            <p className="text-muted-foreground mb-8">
              Your professional resume is ready for download. Review the preview and export when you're satisfied.
            </p>
            <Button size="lg" onClick={() => window.print()}>
              Export as PDF
            </Button>
          </div>
        );
      default:
        return null;
    }
  };

  // Auto-save on data change
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      saveToStorage();
    }, 1000);

    return () => clearTimeout(timeoutId);
  }, [resumeData, saveToStorage]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Progress Header */}
      <div className="bg-white border-b border-border sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">Build Your Resume</h1>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <div className="w-2 h-2 bg-primary rounded-full"></div>
              <span>Step {currentStep} of {STEPS.length}</span>
            </div>
          </div>
          
          <div className="mb-4">
            <Progress value={progressPercentage} className="h-2" />
          </div>
          
          {/* Step Navigation */}
          <div className="flex items-center justify-center space-x-8 overflow-x-auto">
            {STEPS.map((step) => (
              <button
                key={step.id}
                onClick={() => setCurrentStep(step.id)}
                className="flex items-center space-x-2 min-w-0 flex-shrink-0"
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
                  step.id < currentStep
                    ? "bg-green-500 text-white"
                    : step.id === currentStep
                    ? "bg-primary text-white"
                    : "bg-muted text-muted-foreground"
                }`}>
                  {step.id < currentStep ? (
                    <CheckCircle className="h-5 w-5" />
                  ) : (
                    step.id
                  )}
                </div>
                <span className={`font-medium transition-colors ${
                  step.id === currentStep
                    ? "text-primary"
                    : step.id < currentStep
                    ? "text-green-600"
                    : "text-muted-foreground"
                }`}>
                  {step.name}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex min-h-screen">
        {/* Left Panel - Form */}
        <div className="w-1/2 overflow-y-auto">
          <div className="p-6">
            <Card>
              <CardContent className="p-8">
                {renderStepContent()}
                
                {/* Navigation Buttons */}
                {currentStep < 5 && (
                  <div className="flex items-center justify-between pt-8 border-t border-border mt-8">
                    <Button
                      variant="outline"
                      onClick={handlePrevious}
                      disabled={currentStep === 1}
                    >
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      Previous
                    </Button>
                    
                    <Button
                      onClick={handleNext}
                      disabled={!isStepValid(currentStep)}
                    >
                      {currentStep === STEPS.length - 1 ? "Complete" : "Next Step"}
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Right Panel - Preview & AI */}
        <div className="w-1/2 bg-muted/50 overflow-y-auto">
          <div className="p-6 space-y-6">
            <AISuggestions 
              currentStep={currentStep}
              resumeData={resumeData}
              onApplySuggestion={(field, value) => {
                updateResumeData(value);
                toast({
                  title: "AI suggestion applied",
                  description: "Your resume has been enhanced with AI-generated content.",
                });
              }}
            />
            
            <ResumePreview
              data={resumeData}
              template={resumeData.template || "modern"}
              onTemplateChange={(template) => updateResumeData({ template })}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

import { Link } from "wouter";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Wand2, 
  Eye, 
  Download, 
  Shield, 
  Lightbulb,
  Search,
  Rocket,
  CheckCircle
} from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary to-purple-600 text-white py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold mb-6 leading-tight">
                Build Professional Resumes with{" "}
                <span className="text-yellow-300">AI Power</span>
              </h1>
              <p className="text-xl mb-8 opacity-90">
                Transform your career story into ATS-optimized, professionally designed resumes in minutes. 
                Our AI analyzes job descriptions and crafts content that gets you noticed.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/builder">
                  <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                    <Wand2 className="mr-2 h-5 w-5" />
                    Start Building Now
                  </Button>
                </Link>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
                  View Templates
                </Button>
              </div>
              <div className="mt-8 flex items-center space-x-6 text-sm opacity-80">
                <div className="flex items-center">
                  <CheckCircle className="mr-2 h-4 w-4" />
                  No registration required
                </div>
                <div className="flex items-center">
                  <Shield className="mr-2 h-4 w-4" />
                  Privacy protected
                </div>
                <div className="flex items-center">
                  <Download className="mr-2 h-4 w-4" />
                  Multiple formats
                </div>
              </div>
            </div>
            <div className="relative">
              <Card className="transform rotate-3 hover:rotate-0 transition-transform duration-300">
                <CardContent className="p-6">
                  <div className="bg-muted rounded-lg p-4 mb-4">
                    <div className="h-3 bg-primary rounded w-3/4 mb-2"></div>
                    <div className="h-2 bg-muted-foreground/30 rounded w-1/2 mb-4"></div>
                    <div className="space-y-2">
                      <div className="h-2 bg-muted-foreground/20 rounded"></div>
                      <div className="h-2 bg-muted-foreground/20 rounded w-5/6"></div>
                      <div className="h-2 bg-muted-foreground/20 rounded w-3/4"></div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                      <Wand2 className="mr-1 h-3 w-3" />
                      AI Optimized
                    </Badge>
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      <CheckCircle className="mr-1 h-3 w-3" />
                      ATS Ready
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Template Showcase */}
      <section id="templates" className="py-16 bg-muted/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Professional Resume Templates</h2>
            <p className="text-xl text-muted-foreground">
              Choose from our collection of ATS-optimized, professionally designed templates
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Modern Professional",
                description: "Clean, contemporary design perfect for tech and creative industries",
                preview: "bg-primary",
              },
              {
                name: "Executive Classic",
                description: "Traditional layout ideal for senior positions and conservative industries",
                preview: "bg-slate-600",
              },
              {
                name: "Creative Minimal",
                description: "Stylish design that balances creativity with professionalism",
                preview: "bg-purple-500",
              },
            ].map((template, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300">
                <div className="aspect-[3/4] bg-muted p-6">
                  <div className="w-full h-full bg-white rounded-lg shadow-sm p-4 transform group-hover:scale-105 transition-transform duration-300">
                    <div className="mb-4 text-center">
                      <div className={`h-4 ${template.preview} rounded w-3/4 mx-auto mb-2`}></div>
                      <div className="h-2 bg-muted rounded w-1/2 mx-auto mb-1"></div>
                      <div className="h-1 bg-muted-foreground/30 rounded w-2/3 mx-auto"></div>
                    </div>
                    <div className="h-px bg-muted mb-3"></div>
                    <div className="space-y-2">
                      <div className="h-2 bg-green-500 rounded w-1/3 mb-1"></div>
                      <div className="h-1 bg-muted rounded"></div>
                      <div className="h-1 bg-muted rounded w-5/6"></div>
                      <div className="h-1 bg-muted rounded w-3/4"></div>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold mb-2">{template.name}</h3>
                  <p className="text-muted-foreground text-sm mb-4">{template.description}</p>
                  <div className="flex items-center justify-between">
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      <CheckCircle className="mr-1 h-3 w-3" />
                      ATS Optimized
                    </Badge>
                    <Link href="/builder">
                      <Button size="sm">Use Template</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Powerful AI Features</h2>
            <p className="text-xl text-muted-foreground">Everything you need to create the perfect resume</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Wand2,
                title: "AI Content Generation",
                description: "Let AI craft compelling professional summaries, job descriptions, and skill statements that showcase your experience perfectly.",
                color: "bg-purple-500",
              },
              {
                icon: Search,
                title: "ATS Optimization",
                description: "Ensure your resume passes Applicant Tracking Systems with industry-specific keywords and proper formatting.",
                color: "bg-green-500",
              },
              {
                icon: Eye,
                title: "Real-time Preview",
                description: "See exactly how your resume looks as you build it with instant preview updates and template switching.",
                color: "bg-primary",
              },
              {
                icon: Download,
                title: "Multiple Export Formats",
                description: "Download your resume in PDF, DOCX, or HTML formats with perfect formatting preservation.",
                color: "bg-orange-500",
              },
              {
                icon: Shield,
                title: "Privacy Protected",
                description: "Your data stays secure with local storage - no server uploads, no data sharing, complete privacy control.",
                color: "bg-red-500",
              },
              {
                icon: Lightbulb,
                title: "Smart Suggestions",
                description: "Get intelligent recommendations for improving your resume content based on industry best practices.",
                color: "bg-purple-500",
              },
            ].map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center mb-4`}>
                    <feature.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Export Section */}
      <section className="py-16 bg-gradient-to-r from-slate-800 to-slate-700 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Export Your Perfect Resume</h2>
          <p className="text-xl text-slate-300 mb-8">Get your professionally designed resume in any format you need</p>
          
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {[
              { icon: FileText, name: "PDF Format", description: "Perfect for email applications and ATS systems", color: "bg-red-500" },
              { icon: FileText, name: "DOCX Format", description: "Editable Word document for further customization", color: "bg-blue-500" },
              { icon: FileText, name: "HTML Format", description: "Web-ready format for online portfolios", color: "bg-green-500" },
            ].map((format, index) => (
              <Card key={index} className="bg-white/10 border-white/20 backdrop-blur-sm">
                <CardContent className="p-6 text-center">
                  <div className={`w-16 h-16 ${format.color} rounded-lg flex items-center justify-center mx-auto mb-4`}>
                    <format.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{format.name}</h3>
                  <p className="text-slate-300 text-sm">{format.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <Link href="/builder">
            <Button size="lg" className="bg-white text-slate-800 hover:bg-gray-100">
              <Rocket className="mr-2 h-5 w-5" />
              Start Building Your Resume
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}

import jsPDF from 'jspdf';
import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, BorderStyle } from 'docx';
import { saveAs } from 'file-saver';
import { type ResumeData } from '@shared/schema';

export async function exportToPDF(data: ResumeData, template: string = 'modern'): Promise<void> {
  const pdf = new jsPDF('p', 'mm', 'a4');
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  const margin = 20;
  const contentWidth = pageWidth - 2 * margin;
  let currentY = margin;

  // Set default font
  pdf.setFont('helvetica');

  // Helper function to add text with word wrapping
  const addText = (text: string, fontSize: number, isBold: boolean = false, color: string = '#000000') => {
    pdf.setFontSize(fontSize);
    pdf.setFont('helvetica', isBold ? 'bold' : 'normal');
    pdf.setTextColor(color);
    
    const lines = pdf.splitTextToSize(text, contentWidth);
    const lineHeight = fontSize * 0.35;
    
    // Check if we need a new page
    if (currentY + (lines.length * lineHeight) > pageHeight - margin) {
      pdf.addPage();
      currentY = margin;
    }
    
    pdf.text(lines, margin, currentY);
    currentY += lines.length * lineHeight + 2;
    return currentY;
  };

  // Helper function to add a section header
  const addSectionHeader = (title: string) => {
    currentY += 5;
    pdf.setFillColor(47, 122, 235); // Primary blue color
    pdf.rect(margin, currentY - 3, contentWidth, 8, 'F');
    pdf.setTextColor('#FFFFFF');
    pdf.setFontSize(12);
    pdf.setFont('helvetica', 'bold');
    pdf.text(title.toUpperCase(), margin + 2, currentY + 2);
    currentY += 10;
    pdf.setTextColor('#000000');
  };

  // Header Section
  if (template === 'modern') {
    // Modern template with dark header
    pdf.setFillColor(30, 41, 59); // Slate-800
    pdf.rect(0, 0, pageWidth, 60, 'F');
    
    // Name
    pdf.setTextColor('#FFFFFF');
    pdf.setFontSize(24);
    pdf.setFont('helvetica', 'bold');
    const fullName = `${data.personalInfo?.firstName || ''} ${data.personalInfo?.lastName || ''}`.trim();
    pdf.text(fullName, margin, 25);
    
    // Title
    if (data.personalInfo?.title) {
      pdf.setFontSize(16);
      pdf.setFont('helvetica', 'normal');
      pdf.text(data.personalInfo.title, margin, 35);
    }
    
    // Contact Info
    pdf.setFontSize(10);
    let contactY = 45;
    const contactInfo = [
      data.personalInfo?.email,
      data.personalInfo?.phone,
      data.personalInfo?.location,
      data.personalInfo?.linkedin
    ].filter(Boolean);
    
    contactInfo.forEach((info, index) => {
      if (info) {
        const xPos = margin + (index % 2) * (contentWidth / 2);
        const yPos = contactY + Math.floor(index / 2) * 5;
        pdf.text(info, xPos, yPos);
      }
    });
    
    currentY = 70;
  } else {
    // Classic template with centered header
    pdf.setTextColor('#000000');
    pdf.setFontSize(24);
    pdf.setFont('helvetica', 'bold');
    const fullName = `${data.personalInfo?.firstName || ''} ${data.personalInfo?.lastName || ''}`.trim();
    const nameWidth = pdf.getTextWidth(fullName);
    pdf.text(fullName, (pageWidth - nameWidth) / 2, currentY);
    currentY += 10;
    
    if (data.personalInfo?.title) {
      pdf.setFontSize(16);
      pdf.setFont('helvetica', 'normal');
      const titleWidth = pdf.getTextWidth(data.personalInfo.title);
      pdf.text(data.personalInfo.title, (pageWidth - titleWidth) / 2, currentY);
      currentY += 10;
    }
    
    // Contact info centered
    pdf.setFontSize(10);
    const contactInfo = [
      data.personalInfo?.email,
      data.personalInfo?.phone,
      data.personalInfo?.location
    ].filter(Boolean).join(' | ');
    
    if (contactInfo) {
      const contactWidth = pdf.getTextWidth(contactInfo);
      pdf.text(contactInfo, (pageWidth - contactWidth) / 2, currentY);
      currentY += 15;
    }
    
    // Add separator line
    pdf.setDrawColor(150, 150, 150);
    pdf.line(margin, currentY, pageWidth - margin, currentY);
    currentY += 10;
  }

  // Professional Summary
  if (data.personalInfo?.summary) {
    addSectionHeader('Professional Summary');
    addText(data.personalInfo.summary, 10, false);
  }

  // Work Experience
  if (data.experience.length > 0) {
    addSectionHeader('Work Experience');
    
    data.experience.forEach((exp) => {
      // Job title and dates
      pdf.setFontSize(12);
      pdf.setFont('helvetica', 'bold');
      pdf.setTextColor('#000000');
      
      const jobTitle = exp.jobTitle || '';
      const dateRange = `${exp.startDate || ''} - ${exp.isCurrent ? 'Present' : exp.endDate || ''}`;
      
      // Check for page break
      if (currentY > pageHeight - 40) {
        pdf.addPage();
        currentY = margin;
      }
      
      pdf.text(jobTitle, margin, currentY);
      const dateWidth = pdf.getTextWidth(dateRange);
      pdf.text(dateRange, pageWidth - margin - dateWidth, currentY);
      currentY += 5;
      
      // Company
      if (exp.company) {
        pdf.setFontSize(11);
        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor('#4A5568');
        pdf.text(exp.company, margin, currentY);
        currentY += 5;
      }
      
      // Description
      if (exp.description) {
        addText(exp.description, 10, false);
      }
      
      // Achievements
      if (exp.achievements && exp.achievements.length > 0) {
        exp.achievements.forEach((achievement) => {
          if (achievement.trim()) {
            addText(`• ${achievement}`, 10, false);
          }
        });
      }
      
      currentY += 3;
    });
  }

  // Education
  if (data.education.length > 0) {
    addSectionHeader('Education');
    
    data.education.forEach((edu) => {
      pdf.setFontSize(12);
      pdf.setFont('helvetica', 'bold');
      pdf.setTextColor('#000000');
      
      const degree = edu.degree || '';
      const dateRange = `${edu.startDate || ''} - ${edu.endDate || ''}`;
      
      // Check for page break
      if (currentY > pageHeight - 30) {
        pdf.addPage();
        currentY = margin;
      }
      
      pdf.text(degree, margin, currentY);
      const dateWidth = pdf.getTextWidth(dateRange);
      pdf.text(dateRange, pageWidth - margin - dateWidth, currentY);
      currentY += 5;
      
      // Institution
      if (edu.institution) {
        pdf.setFontSize(11);
        pdf.setFont('helvetica', 'normal');
        pdf.setTextColor('#4A5568');
        pdf.text(edu.institution, margin, currentY);
        currentY += 5;
      }
      
      // GPA
      if (edu.gpa) {
        addText(`GPA: ${edu.gpa}`, 10, false);
      }
      
      // Achievements
      if (edu.achievements && edu.achievements.length > 0) {
        edu.achievements.forEach((achievement) => {
          if (achievement.trim()) {
            addText(`• ${achievement}`, 10, false);
          }
        });
      }
      
      currentY += 3;
    });
  }

  // Skills
  if (data.skills.length > 0) {
    addSectionHeader('Skills');
    
    data.skills.forEach((skillGroup) => {
      if (skillGroup.category && skillGroup.skills.length > 0) {
        const skillText = `${skillGroup.category}: ${skillGroup.skills.join(', ')}`;
        addText(skillText, 10, false);
        currentY += 2;
      }
    });
  }

  // Generate filename
  const fileName = `${data.personalInfo?.firstName || 'Resume'}_${data.personalInfo?.lastName || 'TAC'}_Resume.pdf`;
  
  // Save the PDF
  pdf.save(fileName);
}

export async function exportToHTML(data: ResumeData, template: string = 'modern'): Promise<void> {
  // Create HTML content based on template
  const htmlContent = generateHTMLContent(data, template);
  
  // Create blob and download
  const blob = new Blob([htmlContent], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${data.personalInfo?.firstName || 'Resume'}_${data.personalInfo?.lastName || 'TAC'}_Resume.html`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function generateHTMLContent(data: ResumeData, template: string): string {
  const { personalInfo, experience, education, skills } = data;
  
  const styles = template === 'modern' ? `
    <style>
      body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; line-height: 1.6; color: #333; }
      .header { background: #1e293b; color: white; padding: 2rem; }
      .header h1 { margin: 0; font-size: 2.5rem; }
      .header h2 { margin: 0.5rem 0; font-size: 1.25rem; color: #cbd5e1; }
      .contact { display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; margin-top: 1rem; font-size: 0.9rem; }
      .content { padding: 2rem; }
      .section { margin-bottom: 2rem; }
      .section-title { font-size: 1.25rem; font-weight: bold; color: #1e293b; border-bottom: 2px solid #3b82f6; padding-bottom: 0.25rem; margin-bottom: 1rem; text-transform: uppercase; }
      .job { margin-bottom: 1.5rem; }
      .job-header { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 0.25rem; }
      .job-title { font-weight: bold; font-size: 1.1rem; }
      .job-company { color: #64748b; font-weight: 600; }
      .job-date { color: #64748b; font-size: 0.9rem; }
      .achievements { list-style: none; padding: 0; }
      .achievements li { position: relative; padding-left: 1rem; margin-bottom: 0.25rem; }
      .achievements li:before { content: '•'; color: #3b82f6; position: absolute; left: 0; }
      .skills-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
      .skill-category { font-weight: bold; color: #374151; }
    </style>
  ` : `
    <style>
      body { font-family: 'Times New Roman', serif; margin: 0; padding: 2rem; line-height: 1.6; color: #333; }
      .header { text-align: center; border-bottom: 2px solid #ccc; padding-bottom: 1.5rem; margin-bottom: 2rem; }
      .header h1 { margin: 0; font-size: 2.5rem; }
      .header h2 { margin: 0.5rem 0; font-size: 1.25rem; color: #666; }
      .contact { margin-top: 1rem; font-size: 0.9rem; color: #666; }
      .section { margin-bottom: 2rem; }
      .section-title { font-size: 1.25rem; font-weight: bold; color: #333; border-bottom: 1px solid #ccc; padding-bottom: 0.25rem; margin-bottom: 1rem; text-transform: uppercase; letter-spacing: 2px; }
      .job { margin-bottom: 1.5rem; }
      .job-header { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 0.25rem; }
      .job-title { font-weight: bold; font-size: 1.1rem; }
      .job-company { color: #666; font-style: italic; font-weight: 600; }
      .job-date { color: #666; font-size: 0.9rem; font-style: italic; }
      .achievements { list-style: disc; padding-left: 1.5rem; }
      .skill-item { margin-bottom: 0.5rem; }
      .skill-category { font-weight: bold; }
    </style>
  `;

  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${personalInfo?.firstName} ${personalInfo?.lastName} - Resume</title>
      ${styles}
    </head>
    <body>
      <div class="header">
        <h1>${personalInfo?.firstName || ''} ${personalInfo?.lastName || ''}</h1>
        <h2>${personalInfo?.title || ''}</h2>
        <div class="contact">
          ${personalInfo?.email ? `<div>📧 ${personalInfo.email}</div>` : ''}
          ${personalInfo?.phone ? `<div>📞 ${personalInfo.phone}</div>` : ''}
          ${personalInfo?.location ? `<div>📍 ${personalInfo.location}</div>` : ''}
          ${personalInfo?.linkedin ? `<div>🔗 ${personalInfo.linkedin}</div>` : ''}
        </div>
      </div>
      
      <div class="content">
        ${personalInfo?.summary ? `
          <div class="section">
            <h3 class="section-title">Professional Summary</h3>
            <p>${personalInfo.summary}</p>
          </div>
        ` : ''}
        
        ${experience.length > 0 ? `
          <div class="section">
            <h3 class="section-title">Work Experience</h3>
            ${experience.map(exp => `
              <div class="job">
                <div class="job-header">
                  <div>
                    <div class="job-title">${exp.jobTitle || ''}</div>
                    <div class="job-company">${exp.company || ''}</div>
                  </div>
                  <div class="job-date">${exp.startDate || ''} - ${exp.isCurrent ? 'Present' : exp.endDate || ''}</div>
                </div>
                ${exp.description ? `<p>${exp.description}</p>` : ''}
                ${exp.achievements && exp.achievements.length > 0 ? `
                  <ul class="achievements">
                    ${exp.achievements.map(achievement => `<li>${achievement}</li>`).join('')}
                  </ul>
                ` : ''}
              </div>
            `).join('')}
          </div>
        ` : ''}
        
        ${education.length > 0 ? `
          <div class="section">
            <h3 class="section-title">Education</h3>
            ${education.map(edu => `
              <div class="job">
                <div class="job-header">
                  <div>
                    <div class="job-title">${edu.degree || ''}</div>
                    <div class="job-company">${edu.institution || ''}</div>
                    ${edu.gpa ? `<div>GPA: ${edu.gpa}</div>` : ''}
                  </div>
                  <div class="job-date">${edu.startDate || ''} - ${edu.endDate || ''}</div>
                </div>
                ${edu.achievements && edu.achievements.length > 0 ? `
                  <ul class="achievements">
                    ${edu.achievements.map(achievement => `<li>${achievement}</li>`).join('')}
                  </ul>
                ` : ''}
              </div>
            `).join('')}
          </div>
        ` : ''}
        
        ${skills.length > 0 ? `
          <div class="section">
            <h3 class="section-title">Skills</h3>
            <div class="${template === 'modern' ? 'skills-grid' : ''}">
              ${skills.map(skillGroup => `
                <div class="${template === 'modern' ? '' : 'skill-item'}">
                  <span class="skill-category">${skillGroup.category}:</span>
                  ${skillGroup.skills.join(', ')}
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}
      </div>
    </body>
    </html>
  `;
}

export async function exportToDOCX(data: ResumeData, template: string = 'modern'): Promise<void> {
  const { personalInfo, experience, education, skills } = data;
  
  // Create document sections
  const docSections = [];

  // Header section
  const headerParagraphs = [
    new Paragraph({
      children: [
        new TextRun({
          text: `${personalInfo?.firstName || ''} ${personalInfo?.lastName || ''}`,
          bold: true,
          size: 32,
        }),
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: 200 },
    }),
    new Paragraph({
      children: [
        new TextRun({
          text: personalInfo?.title || '',
          size: 24,
          color: "666666",
        }),
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: 400 },
    }),
  ];

  // Contact information
  const contactInfo = [
    personalInfo?.email,
    personalInfo?.phone,
    personalInfo?.location,
    personalInfo?.linkedin
  ].filter(Boolean).join(' | ');

  if (contactInfo) {
    headerParagraphs.push(
      new Paragraph({
        children: [
          new TextRun({
            text: contactInfo,
            size: 20,
            color: "666666",
          }),
        ],
        alignment: AlignmentType.CENTER,
        spacing: { after: 400 },
      })
    );
  }

  docSections.push(...headerParagraphs);

  // Professional Summary
  if (personalInfo?.summary) {
    docSections.push(
      new Paragraph({
        children: [
          new TextRun({
            text: "PROFESSIONAL SUMMARY",
            bold: true,
            size: 24,
            color: "2563EB",
          }),
        ],
        spacing: { before: 400, after: 200 },
      }),
      new Paragraph({
        children: [
          new TextRun({
            text: personalInfo.summary,
            size: 22,
          }),
        ],
        spacing: { after: 400 },
      })
    );
  }

  // Work Experience
  if (experience.length > 0) {
    docSections.push(
      new Paragraph({
        children: [
          new TextRun({
            text: "WORK EXPERIENCE",
            bold: true,
            size: 24,
            color: "2563EB",
          }),
        ],
        spacing: { before: 400, after: 200 },
      })
    );

    experience.forEach((exp) => {
      docSections.push(
        new Paragraph({
          children: [
            new TextRun({
              text: exp.jobTitle || '',
              bold: true,
              size: 22,
            }),
            new TextRun({
              text: ` | ${exp.company || ''}`,
              size: 22,
              color: "666666",
            }),
            new TextRun({
              text: ` | ${exp.startDate || ''} - ${exp.isCurrent ? 'Present' : exp.endDate || ''}`,
              size: 20,
              color: "999999",
            }),
          ],
          spacing: { before: 200, after: 100 },
        })
      );

      if (exp.description) {
        docSections.push(
          new Paragraph({
            children: [
              new TextRun({
                text: exp.description,
                size: 20,
              }),
            ],
            spacing: { after: 100 },
          })
        );
      }

      if (exp.achievements && exp.achievements.length > 0) {
        exp.achievements.forEach((achievement) => {
          docSections.push(
            new Paragraph({
              children: [
                new TextRun({
                  text: `• ${achievement}`,
                  size: 20,
                }),
              ],
              spacing: { after: 50 },
            })
          );
        });
      }
    });
  }

  // Education
  if (education.length > 0) {
    docSections.push(
      new Paragraph({
        children: [
          new TextRun({
            text: "EDUCATION",
            bold: true,
            size: 24,
            color: "2563EB",
          }),
        ],
        spacing: { before: 400, after: 200 },
      })
    );

    education.forEach((edu) => {
      docSections.push(
        new Paragraph({
          children: [
            new TextRun({
              text: edu.degree || '',
              bold: true,
              size: 22,
            }),
            new TextRun({
              text: ` | ${edu.institution || ''}`,
              size: 22,
              color: "666666",
            }),
            new TextRun({
              text: ` | ${edu.startDate || ''} - ${edu.endDate || ''}`,
              size: 20,
              color: "999999",
            }),
          ],
          spacing: { before: 200, after: 100 },
        })
      );

      if (edu.gpa) {
        docSections.push(
          new Paragraph({
            children: [
              new TextRun({
                text: `GPA: ${edu.gpa}`,
                size: 20,
                color: "666666",
              }),
            ],
            spacing: { after: 100 },
          })
        );
      }

      if (edu.achievements && edu.achievements.length > 0) {
        edu.achievements.forEach((achievement) => {
          docSections.push(
            new Paragraph({
              children: [
                new TextRun({
                  text: `• ${achievement}`,
                  size: 20,
                }),
              ],
              spacing: { after: 50 },
            })
          );
        });
      }
    });
  }

  // Skills
  if (skills.length > 0) {
    docSections.push(
      new Paragraph({
        children: [
          new TextRun({
            text: "SKILLS",
            bold: true,
            size: 24,
            color: "2563EB",
          }),
        ],
        spacing: { before: 400, after: 200 },
      })
    );

    skills.forEach((skillGroup) => {
      if (skillGroup.category && skillGroup.skills.length > 0) {
        docSections.push(
          new Paragraph({
            children: [
              new TextRun({
                text: `${skillGroup.category}: `,
                bold: true,
                size: 20,
              }),
              new TextRun({
                text: skillGroup.skills.join(', '),
                size: 20,
              }),
            ],
            spacing: { after: 100 },
          })
        );
      }
    });
  }

  // Create the document
  const doc = new Document({
    sections: [
      {
        properties: {},
        children: docSections,
      },
    ],
  });

  // Generate and save the document
  const buffer = await Packer.toBuffer(doc);
  const fileName = `${personalInfo?.firstName || 'Resume'}_${personalInfo?.lastName || 'TAC'}_Resume.docx`;
  
  saveAs(new Blob([buffer]), fileName);
}

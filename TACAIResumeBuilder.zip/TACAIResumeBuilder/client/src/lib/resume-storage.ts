import { type ResumeData, resumeDataSchema } from '@shared/schema';

const STORAGE_KEY = 'tacResumeData';
const AUTO_SAVE_KEY = 'tacResumeAutoSave';

export interface StoredResumeData extends ResumeData {
  lastModified: string;
  version: string;
}

export class ResumeStorage {
  private static instance: ResumeStorage;
  
  public static getInstance(): ResumeStorage {
    if (!ResumeStorage.instance) {
      ResumeStorage.instance = new ResumeStorage();
    }
    return ResumeStorage.instance;
  }

  /**
   * Save resume data to localStorage with timestamp and version
   */
  save(data: ResumeData): boolean {
    try {
      // Validate data before saving
      const validatedData = resumeDataSchema.parse(data);
      
      const storedData: StoredResumeData = {
        ...validatedData,
        lastModified: new Date().toISOString(),
        version: '1.0.0'
      };
      
      localStorage.setItem(STORAGE_KEY, JSON.stringify(storedData));
      return true;
    } catch (error) {
      console.error('Failed to save resume data:', error);
      return false;
    }
  }

  /**
   * Load resume data from localStorage
   */
  load(): ResumeData | null {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (!stored) return null;
      
      const parsedData = JSON.parse(stored);
      
      // Validate loaded data
      const validatedData = resumeDataSchema.parse(parsedData);
      return validatedData;
    } catch (error) {
      console.error('Failed to load resume data:', error);
      return null;
    }
  }

  /**
   * Auto-save resume data (used for temporary saves during editing)
   */
  autoSave(data: Partial<ResumeData>): boolean {
    try {
      const autoSaveData = {
        ...data,
        lastAutoSave: new Date().toISOString()
      };
      
      localStorage.setItem(AUTO_SAVE_KEY, JSON.stringify(autoSaveData));
      return true;
    } catch (error) {
      console.error('Failed to auto-save resume data:', error);
      return false;
    }
  }

  /**
   * Load auto-saved data
   */
  loadAutoSave(): Partial<ResumeData> | null {
    try {
      const stored = localStorage.getItem(AUTO_SAVE_KEY);
      if (!stored) return null;
      
      return JSON.parse(stored);
    } catch (error) {
      console.error('Failed to load auto-saved data:', error);
      return null;
    }
  }

  /**
   * Clear auto-saved data
   */
  clearAutoSave(): void {
    localStorage.removeItem(AUTO_SAVE_KEY);
  }

  /**
   * Get the last modified timestamp
   */
  getLastModified(): string | null {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (!stored) return null;
      
      const data = JSON.parse(stored) as StoredResumeData;
      return data.lastModified;
    } catch (error) {
      return null;
    }
  }

  /**
   * Check if there's saved data available
   */
  hasData(): boolean {
    return localStorage.getItem(STORAGE_KEY) !== null;
  }

  /**
   * Export resume data as JSON
   */
  export(data: ResumeData): void {
    try {
      const exportData = {
        ...data,
        exportedAt: new Date().toISOString(),
        exportedBy: 'TAC Resume Builder'
      };
      
      const dataStr = JSON.stringify(exportData, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `${data.personalInfo?.firstName || 'Resume'}_${data.personalInfo?.lastName || 'TAC'}_data.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export resume data:', error);
      throw new Error('Export failed');
    }
  }

  /**
   * Import resume data from JSON file
   */
  async import(file: File): Promise<ResumeData> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const text = e.target?.result as string;
          const data = JSON.parse(text);
          
          // Validate imported data
          const validatedData = resumeDataSchema.parse(data);
          resolve(validatedData);
        } catch (error) {
          reject(new Error('Invalid resume data file'));
        }
      };
      
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsText(file);
    });
  }

  /**
   * Clear all stored resume data
   */
  clear(): void {
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(AUTO_SAVE_KEY);
  }

  /**
   * Get storage usage information
   */
  getStorageInfo(): { used: number; available: number; percentage: number } {
    try {
      let totalUsed = 0;
      
      for (let key in localStorage) {
        if (localStorage.hasOwnProperty(key)) {
          totalUsed += localStorage[key].length;
        }
      }
      
      // localStorage typically has 5-10MB limit, we'll assume 5MB
      const totalAvailable = 5 * 1024 * 1024; // 5MB in bytes
      const used = totalUsed * 2; // UTF-16 encoding uses 2 bytes per character
      const percentage = (used / totalAvailable) * 100;
      
      return {
        used,
        available: totalAvailable - used,
        percentage: Math.min(percentage, 100)
      };
    } catch (error) {
      return { used: 0, available: 0, percentage: 0 };
    }
  }

  /**
   * Create a backup of current data
   */
  createBackup(): string | null {
    try {
      const data = this.load();
      if (!data) return null;
      
      const backup = {
        ...data,
        backupCreated: new Date().toISOString(),
        backupVersion: '1.0.0'
      };
      
      return JSON.stringify(backup);
    } catch (error) {
      console.error('Failed to create backup:', error);
      return null;
    }
  }

  /**
   * Restore from backup data
   */
  restoreFromBackup(backupData: string): boolean {
    try {
      const data = JSON.parse(backupData);
      const validatedData = resumeDataSchema.parse(data);
      return this.save(validatedData);
    } catch (error) {
      console.error('Failed to restore from backup:', error);
      return false;
    }
  }
}

// Export singleton instance
export const resumeStorage = ResumeStorage.getInstance();

// Export utility functions
export const saveResumeData = (data: ResumeData) => resumeStorage.save(data);
export const loadResumeData = () => resumeStorage.load();
export const autoSaveResumeData = (data: Partial<ResumeData>) => resumeStorage.autoSave(data);
export const clearResumeData = () => resumeStorage.clear();

import { type ResumeData } from "@shared/schema";
import { Mail, Phone, MapPin, Linkedin } from "lucide-react";

interface ExecutiveTemplateProps {
  data: ResumeData;
}

export default function ExecutiveTemplate({ data }: ExecutiveTemplateProps) {
  const { personalInfo, experience, education, skills } = data;

  return (
    <div className="bg-white text-slate-900 font-serif leading-relaxed" style={{ fontSize: "11px" }}>
      {/* Executive Header */}
      <div className="border-b-4 border-slate-800 pb-6 mb-8 p-8">
        <div className="text-center">
          <h1 className="text-5xl font-bold mb-3 text-slate-800 tracking-wide">
            {personalInfo?.firstName} {personalInfo?.lastName}
          </h1>
          <div className="w-24 h-1 bg-slate-800 mx-auto mb-4"></div>
          <h2 className="text-2xl text-slate-600 mb-6 font-light tracking-widest uppercase">
            {personalInfo?.title}
          </h2>
          
          <div className="flex justify-center space-x-8 text-sm text-slate-600">
            {personalInfo?.email && (
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span>{personalInfo.email}</span>
              </div>
            )}
            {personalInfo?.phone && (
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span>{personalInfo.phone}</span>
              </div>
            )}
            {personalInfo?.location && (
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4" />
                <span>{personalInfo.location}</span>
              </div>
            )}
            {personalInfo?.linkedin && (
              <div className="flex items-center space-x-2">
                <Linkedin className="w-4 h-4" />
                <span>{personalInfo.linkedin}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="px-8 pb-8">
        {/* Executive Summary */}
        {personalInfo?.summary && (
          <section className="mb-10">
            <h3 className="text-xl font-bold text-slate-800 mb-4 text-center uppercase tracking-widest">
              Executive Summary
            </h3>
            <div className="w-16 h-1 bg-slate-800 mx-auto mb-6"></div>
            <p className="text-slate-700 leading-relaxed text-center text-base italic max-w-4xl mx-auto">
              "{personalInfo.summary}"
            </p>
          </section>
        )}

        {/* Professional Experience */}
        {experience.length > 0 && (
          <section className="mb-10">
            <h3 className="text-xl font-bold text-slate-800 mb-4 text-center uppercase tracking-widest">
              Professional Experience
            </h3>
            <div className="w-16 h-1 bg-slate-800 mx-auto mb-6"></div>
            
            {experience.map((exp, index) => (
              <div key={exp.id || index} className="mb-8 border-l-4 border-slate-300 pl-6">
                <div className="flex justify-between items-baseline mb-2">
                  <div>
                    <h4 className="text-lg font-bold text-slate-800">{exp.jobTitle}</h4>
                    <p className="text-slate-600 font-semibold text-base">{exp.company}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-sm text-slate-500 font-semibold tracking-wide">
                      {exp.startDate} – {exp.isCurrent ? "Present" : exp.endDate}
                    </span>
                    {exp.location && (
                      <p className="text-xs text-slate-500">{exp.location}</p>
                    )}
                  </div>
                </div>
                
                {exp.description && (
                  <p className="text-sm text-slate-700 mb-3 text-justify leading-relaxed">
                    {exp.description}
                  </p>
                )}
                
                {exp.achievements && exp.achievements.length > 0 && (
                  <div className="ml-4">
                    <h5 className="text-sm font-semibold text-slate-700 mb-2 uppercase tracking-wide">
                      Key Achievements:
                    </h5>
                    <ul className="text-sm text-slate-700 space-y-2">
                      {exp.achievements.map((achievement, i) => (
                        <li key={i} className="flex items-start">
                          <span className="mr-3 mt-1 w-2 h-2 bg-slate-600 rounded-full flex-shrink-0"></span>
                          <span className="leading-relaxed">{achievement}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </section>
        )}

        {/* Education & Qualifications */}
        {education.length > 0 && (
          <section className="mb-10">
            <h3 className="text-xl font-bold text-slate-800 mb-4 text-center uppercase tracking-widest">
              Education & Qualifications
            </h3>
            <div className="w-16 h-1 bg-slate-800 mx-auto mb-6"></div>
            
            <div className="grid md:grid-cols-2 gap-6">
              {education.map((edu, index) => (
                <div key={edu.id || index} className="border border-slate-200 p-4 rounded-lg">
                  <div className="text-center">
                    <h4 className="text-base font-bold text-slate-800 mb-1">{edu.degree}</h4>
                    <p className="text-slate-600 font-semibold">{edu.institution}</p>
                    <p className="text-sm text-slate-500 mb-2">
                      {edu.startDate} – {edu.endDate}
                    </p>
                    {edu.gpa && (
                      <p className="text-sm text-slate-600 font-semibold">GPA: {edu.gpa}</p>
                    )}
                    
                    {edu.achievements && edu.achievements.length > 0 && (
                      <div className="mt-3">
                        <h5 className="text-xs font-semibold text-slate-700 mb-1 uppercase tracking-wide">
                          Honors:
                        </h5>
                        <ul className="text-xs text-slate-600 space-y-1">
                          {edu.achievements.map((achievement, i) => (
                            <li key={i}>{achievement}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Core Competencies */}
        {skills.length > 0 && (
          <section>
            <h3 className="text-xl font-bold text-slate-800 mb-4 text-center uppercase tracking-widest">
              Core Competencies
            </h3>
            <div className="w-16 h-1 bg-slate-800 mx-auto mb-6"></div>
            
            <div className="grid md:grid-cols-2 gap-6">
              {skills.map((skillGroup, index) => (
                <div key={skillGroup.id || index} className="text-center">
                  <h4 className="text-base font-bold text-slate-700 mb-3 uppercase tracking-wide border-b border-slate-300 pb-2">
                    {skillGroup.category}
                  </h4>
                  <div className="space-y-2">
                    {skillGroup.skills.map((skill, i) => (
                      <div key={i} className="text-sm text-slate-600 border border-slate-200 rounded px-3 py-1 inline-block mr-2 mb-2">
                        {skill}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
import { type ResumeData } from "@shared/schema";
import { Mail, Phone, MapPin, Linkedin, Github } from "lucide-react";

interface TechnicalTemplateProps {
  data: ResumeData;
}

export default function TechnicalTemplate({ data }: TechnicalTemplateProps) {
  const { personalInfo, experience, education, skills } = data;

  return (
    <div className="bg-white text-slate-900 font-mono leading-relaxed" style={{ fontSize: "11px" }}>
      {/* Header */}
      <div className="bg-slate-900 text-green-400 p-6 font-mono">
        <div className="border border-green-400 p-4">
          <div className="text-center">
            <div className="text-xs text-green-300 mb-2">$ whoami</div>
            <h1 className="text-2xl font-bold mb-2">
              {personalInfo?.firstName} {personalInfo?.lastName}
            </h1>
            <div className="text-xs text-green-300 mb-2">$ echo $ROLE</div>
            <h2 className="text-lg text-green-300 mb-4">{personalInfo?.title}</h2>
            
            <div className="grid grid-cols-2 gap-4 text-xs">
              {personalInfo?.email && (
                <div className="flex items-center space-x-2">
                  <span className="text-green-300">email:</span>
                  <span>{personalInfo.email}</span>
                </div>
              )}
              {personalInfo?.phone && (
                <div className="flex items-center space-x-2">
                  <span className="text-green-300">phone:</span>
                  <span>{personalInfo.phone}</span>
                </div>
              )}
              {personalInfo?.location && (
                <div className="flex items-center space-x-2">
                  <span className="text-green-300">location:</span>
                  <span>{personalInfo.location}</span>
                </div>
              )}
              {personalInfo?.linkedin && (
                <div className="flex items-center space-x-2">
                  <span className="text-green-300">linkedin:</span>
                  <span className="break-all">{personalInfo.linkedin}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* About Section */}
        {personalInfo?.summary && (
          <section className="mb-8">
            <div className="border-l-4 border-green-500 pl-4">
              <h3 className="text-lg font-bold text-slate-800 mb-3">
                <span className="text-green-600">#</span> About
              </h3>
              <div className="bg-slate-50 p-4 rounded border-l-4 border-blue-400">
                <p className="text-slate-700 leading-relaxed">{personalInfo.summary}</p>
              </div>
            </div>
          </section>
        )}

        {/* Technical Skills */}
        {skills.length > 0 && (
          <section className="mb-8">
            <div className="border-l-4 border-green-500 pl-4">
              <h3 className="text-lg font-bold text-slate-800 mb-3">
                <span className="text-green-600">#</span> Technical Stack
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                {skills.map((skillGroup, index) => (
                  <div key={skillGroup.id || index} className="bg-slate-50 p-4 rounded border">
                    <h4 className="text-sm font-bold text-blue-600 mb-2 uppercase tracking-wide">
                      {skillGroup.category}
                    </h4>
                    <div className="space-y-1">
                      {skillGroup.skills.map((skill, i) => (
                        <div key={i} className="flex items-center text-xs">
                          <span className="text-green-500 mr-2">▸</span>
                          <code className="bg-slate-200 px-2 py-1 rounded text-slate-800">
                            {skill}
                          </code>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Work Experience */}
        {experience.length > 0 && (
          <section className="mb-8">
            <div className="border-l-4 border-green-500 pl-4">
              <h3 className="text-lg font-bold text-slate-800 mb-3">
                <span className="text-green-600">#</span> Professional Experience
              </h3>
              
              {experience.map((exp, index) => (
                <div key={exp.id || index} className="mb-6 bg-slate-50 p-4 rounded border">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h4 className="text-base font-bold text-slate-800">
                        <span className="text-blue-600">class</span> {exp.jobTitle} {"{"}
                      </h4>
                      <p className="text-slate-600 text-sm ml-4">
                        <span className="text-purple-600">company:</span> "{exp.company}"
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                        {exp.startDate} - {exp.isCurrent ? "Present" : exp.endDate}
                      </span>
                    </div>
                  </div>
                  
                  {exp.description && (
                    <div className="ml-4 mb-3">
                      <span className="text-green-600 text-xs">// Description</span>
                      <p className="text-sm text-slate-700 bg-white p-2 rounded border-l-4 border-gray-300">
                        {exp.description}
                      </p>
                    </div>
                  )}
                  
                  {exp.achievements && exp.achievements.length > 0 && (
                    <div className="ml-4">
                      <span className="text-green-600 text-xs">// Key Achievements</span>
                      <ul className="text-sm text-slate-700 mt-1">
                        {exp.achievements.map((achievement, i) => (
                          <li key={i} className="flex items-start mb-1">
                            <span className="text-blue-500 mr-2 font-bold">-</span>
                            <span className="bg-white p-1 rounded text-xs border-l-2 border-green-400">
                              {achievement}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  <div className="ml-4 mt-2 text-slate-800">{"}"}</div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Education */}
        {education.length > 0 && (
          <section>
            <div className="border-l-4 border-green-500 pl-4">
              <h3 className="text-lg font-bold text-slate-800 mb-3">
                <span className="text-green-600">#</span> Education & Certifications
              </h3>
              
              {education.map((edu, index) => (
                <div key={edu.id || index} className="mb-4 bg-slate-50 p-4 rounded border">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-base font-bold text-slate-800">
                        <span className="text-purple-600">const</span> degree = "{edu.degree}"
                      </h4>
                      <p className="text-slate-600 text-sm ml-4">
                        <span className="text-blue-600">institution:</span> "{edu.institution}"
                      </p>
                      {edu.gpa && (
                        <p className="text-slate-600 text-sm ml-4">
                          <span className="text-orange-600">gpa:</span> {edu.gpa}
                        </p>
                      )}
                    </div>
                    <span className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded">
                      {edu.startDate} - {edu.endDate}
                    </span>
                  </div>
                  
                  {edu.achievements && edu.achievements.length > 0 && (
                    <div className="ml-4 mt-2">
                      <span className="text-green-600 text-xs">// Achievements</span>
                      <ul className="text-xs text-slate-700 mt-1">
                        {edu.achievements.map((achievement, i) => (
                          <li key={i} className="flex items-start">
                            <span className="text-green-500 mr-2">•</span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
import { type ResumeData } from "@shared/schema";
import { Mail, Phone, MapPin, Linkedin } from "lucide-react";

interface CreativeTemplateProps {
  data: ResumeData;
}

export default function CreativeTemplate({ data }: CreativeTemplateProps) {
  const { personalInfo, experience, education, skills } = data;

  return (
    <div className="bg-white text-slate-900 font-sans leading-relaxed" style={{ fontSize: "11px" }}>
      {/* Header with Sidebar Layout */}
      <div className="flex">
        {/* Left Sidebar */}
        <div className="w-1/3 bg-gradient-to-b from-purple-600 to-blue-600 text-white p-6">
          {/* Profile Section */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-white/70 text-xs">Photo</span>
            </div>
            <h1 className="text-xl font-bold mb-1">
              {personalInfo?.firstName} {personalInfo?.lastName}
            </h1>
            <h2 className="text-sm text-purple-200">{personalInfo?.title}</h2>
          </div>

          {/* Contact Info */}
          <div className="mb-8">
            <h3 className="text-sm font-bold mb-4 uppercase tracking-wide border-b border-white/30 pb-2">
              Contact
            </h3>
            <div className="space-y-3 text-xs">
              {personalInfo?.email && (
                <div className="flex items-center space-x-2">
                  <Mail className="w-3 h-3 text-purple-200" />
                  <span className="break-all">{personalInfo.email}</span>
                </div>
              )}
              {personalInfo?.phone && (
                <div className="flex items-center space-x-2">
                  <Phone className="w-3 h-3 text-purple-200" />
                  <span>{personalInfo.phone}</span>
                </div>
              )}
              {personalInfo?.location && (
                <div className="flex items-center space-x-2">
                  <MapPin className="w-3 h-3 text-purple-200" />
                  <span>{personalInfo.location}</span>
                </div>
              )}
              {personalInfo?.linkedin && (
                <div className="flex items-center space-x-2">
                  <Linkedin className="w-3 h-3 text-purple-200" />
                  <span className="break-all">{personalInfo.linkedin}</span>
                </div>
              )}
            </div>
          </div>

          {/* Skills Section in Sidebar */}
          {skills.length > 0 && (
            <div>
              <h3 className="text-sm font-bold mb-4 uppercase tracking-wide border-b border-white/30 pb-2">
                Skills
              </h3>
              <div className="space-y-4">
                {skills.map((skillGroup, index) => (
                  <div key={skillGroup.id || index}>
                    <h4 className="text-xs font-semibold text-purple-200 mb-2">{skillGroup.category}</h4>
                    <div className="space-y-1">
                      {skillGroup.skills.map((skill, i) => (
                        <div key={i} className="text-xs bg-white/10 rounded px-2 py-1">
                          {skill}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Content */}
        <div className="w-2/3 p-8">
          {/* Professional Summary */}
          {personalInfo?.summary && (
            <section className="mb-8">
              <h3 className="text-lg font-bold text-purple-600 mb-3 uppercase tracking-wide">
                About Me
              </h3>
              <p className="text-slate-700 leading-relaxed text-justify">{personalInfo.summary}</p>
            </section>
          )}

          {/* Work Experience */}
          {experience.length > 0 && (
            <section className="mb-8">
              <h3 className="text-lg font-bold text-purple-600 mb-4 uppercase tracking-wide">
                Experience
              </h3>
              
              {experience.map((exp, index) => (
                <div key={exp.id || index} className="mb-6 relative">
                  {/* Timeline Dot */}
                  <div className="absolute -left-2 top-1 w-3 h-3 bg-purple-500 rounded-full"></div>
                  <div className="border-l-2 border-purple-200 pl-6">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="text-base font-bold text-slate-800">{exp.jobTitle}</h4>
                        <p className="text-purple-600 font-semibold">{exp.company}</p>
                      </div>
                      <span className="text-xs text-slate-500 bg-purple-50 px-2 py-1 rounded">
                        {exp.startDate} - {exp.isCurrent ? "Present" : exp.endDate}
                      </span>
                    </div>
                    
                    {exp.description && (
                      <p className="text-sm text-slate-700 mb-2">{exp.description}</p>
                    )}
                    
                    {exp.achievements && exp.achievements.length > 0 && (
                      <ul className="text-sm text-slate-700 space-y-1">
                        {exp.achievements.map((achievement, i) => (
                          <li key={i} className="flex items-start">
                            <span className="w-2 h-2 bg-purple-400 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              ))}
            </section>
          )}

          {/* Education */}
          {education.length > 0 && (
            <section>
              <h3 className="text-lg font-bold text-purple-600 mb-4 uppercase tracking-wide">
                Education
              </h3>
              
              {education.map((edu, index) => (
                <div key={edu.id || index} className="mb-4 relative">
                  <div className="absolute -left-2 top-1 w-3 h-3 bg-blue-500 rounded-full"></div>
                  <div className="border-l-2 border-blue-200 pl-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="text-base font-bold text-slate-800">{edu.degree}</h4>
                        <p className="text-blue-600 font-semibold">{edu.institution}</p>
                        {edu.gpa && <p className="text-sm text-slate-600">GPA: {edu.gpa}</p>}
                      </div>
                      <span className="text-xs text-slate-500 bg-blue-50 px-2 py-1 rounded">
                        {edu.startDate} - {edu.endDate}
                      </span>
                    </div>
                    
                    {edu.achievements && edu.achievements.length > 0 && (
                      <ul className="text-sm text-slate-700 space-y-1 mt-2">
                        {edu.achievements.map((achievement, i) => (
                          <li key={i} className="flex items-start">
                            <span className="w-2 h-2 bg-blue-400 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                            <span>{achievement}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              ))}
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
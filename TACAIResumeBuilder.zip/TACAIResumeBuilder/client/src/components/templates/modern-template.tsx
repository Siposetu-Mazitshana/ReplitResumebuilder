import { type ResumeData } from "@shared/schema";
import { Mail, Phone, MapPin, Globe, Linkedin } from "lucide-react";

interface ModernTemplateProps {
  data: ResumeData;
}

export default function ModernTemplate({ data }: ModernTemplateProps) {
  const { personalInfo, experience, education, skills } = data;

  return (
    <div className="bg-white text-slate-900 font-sans leading-relaxed" style={{ fontSize: "11px" }}>
      {/* Header */}
      <div className="bg-slate-800 text-white p-8">
        <div className="flex items-start space-x-6">
          {/* Profile Photo Placeholder */}
          <div className="w-24 h-24 bg-slate-600 rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-slate-300 text-xs">Photo</span>
          </div>
          
          <div className="flex-1">
            <h1 className="text-3xl font-bold mb-2">
              {personalInfo?.firstName} {personalInfo?.lastName}
            </h1>
            <h2 className="text-xl text-slate-300 mb-4">{personalInfo?.title}</h2>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              {personalInfo?.email && (
                <div className="flex items-center space-x-2">
                  <Mail className="w-4 h-4 text-slate-300" />
                  <span>{personalInfo.email}</span>
                </div>
              )}
              {personalInfo?.phone && (
                <div className="flex items-center space-x-2">
                  <Phone className="w-4 h-4 text-slate-300" />
                  <span>{personalInfo.phone}</span>
                </div>
              )}
              {personalInfo?.location && (
                <div className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4 text-slate-300" />
                  <span>{personalInfo.location}</span>
                </div>
              )}
              {personalInfo?.linkedin && (
                <div className="flex items-center space-x-2">
                  <Linkedin className="w-4 h-4 text-slate-300" />
                  <span>{personalInfo.linkedin}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="p-8">
        {/* Professional Summary */}
        {personalInfo?.summary && (
          <section className="mb-8">
            <h3 className="text-lg font-bold text-slate-800 mb-3 border-b-2 border-blue-500 pb-1 uppercase tracking-wide">
              Professional Summary
            </h3>
            <p className="text-slate-700 leading-relaxed">{personalInfo.summary}</p>
          </section>
        )}

        {/* Work Experience */}
        {experience.length > 0 && (
          <section className="mb-8">
            <h3 className="text-lg font-bold text-slate-800 mb-4 border-b-2 border-blue-500 pb-1 uppercase tracking-wide">
              Work Experience
            </h3>
            
            {experience.map((exp, index) => (
              <div key={exp.id || index} className="mb-6">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h4 className="text-base font-semibold text-slate-800">{exp.jobTitle}</h4>
                    <p className="text-slate-600 font-medium">{exp.company}</p>
                  </div>
                  <span className="text-sm text-slate-500 whitespace-nowrap">
                    {exp.startDate} - {exp.isCurrent ? "Present" : exp.endDate}
                  </span>
                </div>
                
                {exp.description && (
                  <p className="text-sm text-slate-700 mb-2">{exp.description}</p>
                )}
                
                {exp.achievements && exp.achievements.length > 0 && (
                  <ul className="text-sm text-slate-700 space-y-1 ml-4">
                    {exp.achievements.map((achievement, i) => (
                      <li key={i} className="relative">
                        <span className="absolute -left-4 text-blue-500">•</span>
                        {achievement}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </section>
        )}

        {/* Education */}
        {education.length > 0 && (
          <section className="mb-8">
            <h3 className="text-lg font-bold text-slate-800 mb-4 border-b-2 border-blue-500 pb-1 uppercase tracking-wide">
              Education
            </h3>
            
            {education.map((edu, index) => (
              <div key={edu.id || index} className="mb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-base font-semibold text-slate-800">{edu.degree}</h4>
                    <p className="text-slate-600">{edu.institution}</p>
                    {edu.gpa && <p className="text-sm text-slate-600">GPA: {edu.gpa}</p>}
                  </div>
                  <span className="text-sm text-slate-500 whitespace-nowrap">
                    {edu.startDate} - {edu.endDate}
                  </span>
                </div>
                
                {edu.achievements && edu.achievements.length > 0 && (
                  <ul className="text-sm text-slate-700 space-y-1 ml-4 mt-2">
                    {edu.achievements.map((achievement, i) => (
                      <li key={i} className="relative">
                        <span className="absolute -left-4 text-blue-500">•</span>
                        {achievement}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </section>
        )}

        {/* Skills */}
        {skills.length > 0 && (
          <section>
            <h3 className="text-lg font-bold text-slate-800 mb-4 border-b-2 border-blue-500 pb-1 uppercase tracking-wide">
              Technical Skills
            </h3>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              {skills.map((skillGroup, index) => (
                <div key={skillGroup.id || index}>
                  <h5 className="font-semibold text-slate-700 mb-2">{skillGroup.category}</h5>
                  <p className="text-slate-600">{skillGroup.skills.join(", ")}</p>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

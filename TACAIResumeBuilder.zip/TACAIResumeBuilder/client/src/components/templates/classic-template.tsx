import { type ResumeData } from "@shared/schema";
import { Mail, Phone, MapPin, Globe, Linkedin } from "lucide-react";

interface ClassicTemplateProps {
  data: ResumeData;
}

export default function ClassicTemplate({ data }: ClassicTemplateProps) {
  const { personalInfo, experience, education, skills } = data;

  return (
    <div className="bg-white text-slate-900 font-serif leading-relaxed" style={{ fontSize: "11px" }}>
      {/* Header */}
      <div className="text-center border-b-2 border-slate-300 pb-6 mb-8 p-8">
        <h1 className="text-4xl font-bold mb-2 text-slate-800">
          {personalInfo?.firstName} {personalInfo?.lastName}
        </h1>
        <h2 className="text-xl text-slate-600 mb-4">{personalInfo?.title}</h2>
        
        <div className="flex justify-center space-x-6 text-sm text-slate-600">
          {personalInfo?.email && (
            <div className="flex items-center space-x-1">
              <Mail className="w-4 h-4" />
              <span>{personalInfo.email}</span>
            </div>
          )}
          {personalInfo?.phone && (
            <div className="flex items-center space-x-1">
              <Phone className="w-4 h-4" />
              <span>{personalInfo.phone}</span>
            </div>
          )}
          {personalInfo?.location && (
            <div className="flex items-center space-x-1">
              <MapPin className="w-4 h-4" />
              <span>{personalInfo.location}</span>
            </div>
          )}
        </div>
      </div>

      <div className="px-8 pb-8">
        {/* Professional Summary */}
        {personalInfo?.summary && (
          <section className="mb-8">
            <h3 className="text-lg font-bold text-slate-800 mb-3 uppercase tracking-widest border-b border-slate-300 pb-1">
              Professional Summary
            </h3>
            <p className="text-slate-700 leading-relaxed text-justify">{personalInfo.summary}</p>
          </section>
        )}

        {/* Work Experience */}
        {experience.length > 0 && (
          <section className="mb-8">
            <h3 className="text-lg font-bold text-slate-800 mb-4 uppercase tracking-widest border-b border-slate-300 pb-1">
              Professional Experience
            </h3>
            
            {experience.map((exp, index) => (
              <div key={exp.id || index} className="mb-6">
                <div className="flex justify-between items-baseline mb-1">
                  <h4 className="text-base font-bold text-slate-800">{exp.jobTitle}</h4>
                  <span className="text-sm text-slate-500 italic">
                    {exp.startDate} - {exp.isCurrent ? "Present" : exp.endDate}
                  </span>
                </div>
                <p className="text-slate-600 font-semibold mb-2 italic">{exp.company}</p>
                
                {exp.description && (
                  <p className="text-sm text-slate-700 mb-2 text-justify">{exp.description}</p>
                )}
                
                {exp.achievements && exp.achievements.length > 0 && (
                  <ul className="text-sm text-slate-700 space-y-1">
                    {exp.achievements.map((achievement, i) => (
                      <li key={i} className="flex items-start">
                        <span className="mr-2 mt-1">•</span>
                        <span>{achievement}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </section>
        )}

        {/* Education */}
        {education.length > 0 && (
          <section className="mb-8">
            <h3 className="text-lg font-bold text-slate-800 mb-4 uppercase tracking-widest border-b border-slate-300 pb-1">
              Education
            </h3>
            
            {education.map((edu, index) => (
              <div key={edu.id || index} className="mb-4">
                <div className="flex justify-between items-baseline">
                  <div>
                    <h4 className="text-base font-bold text-slate-800">{edu.degree}</h4>
                    <p className="text-slate-600 italic">{edu.institution}</p>
                    {edu.gpa && <p className="text-sm text-slate-600">GPA: {edu.gpa}</p>}
                  </div>
                  <span className="text-sm text-slate-500 italic">
                    {edu.startDate} - {edu.endDate}
                  </span>
                </div>
                
                {edu.achievements && edu.achievements.length > 0 && (
                  <ul className="text-sm text-slate-700 space-y-1 mt-2">
                    {edu.achievements.map((achievement, i) => (
                      <li key={i} className="flex items-start">
                        <span className="mr-2 mt-1">•</span>
                        <span>{achievement}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </section>
        )}

        {/* Skills */}
        {skills.length > 0 && (
          <section>
            <h3 className="text-lg font-bold text-slate-800 mb-4 uppercase tracking-widest border-b border-slate-300 pb-1">
              Core Competencies
            </h3>
            
            <div className="space-y-3 text-sm">
              {skills.map((skillGroup, index) => (
                <div key={skillGroup.id || index}>
                  <span className="font-bold text-slate-700">{skillGroup.category}:</span>{" "}
                  <span className="text-slate-600">{skillGroup.skills.join(" • ")}</span>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

import { type ResumeData } from "@shared/schema";
import { Mail, Phone, MapPin, Linkedin } from "lucide-react";

interface MinimalTemplateProps {
  data: ResumeData;
}

export default function MinimalTemplate({ data }: MinimalTemplateProps) {
  const { personalInfo, experience, education, skills } = data;

  return (
    <div className="bg-white text-slate-900 font-sans leading-relaxed" style={{ fontSize: "11px" }}>
      {/* Minimal Header */}
      <div className="p-8 border-b border-slate-200">
        <h1 className="text-3xl font-light text-slate-800 mb-2">
          {personalInfo?.firstName} {personalInfo?.lastName}
        </h1>
        <h2 className="text-lg text-slate-600 mb-4 font-light">{personalInfo?.title}</h2>
        
        <div className="flex flex-wrap gap-4 text-sm text-slate-600">
          {personalInfo?.email && (
            <span>{personalInfo.email}</span>
          )}
          {personalInfo?.phone && (
            <span>{personalInfo.phone}</span>
          )}
          {personalInfo?.location && (
            <span>{personalInfo.location}</span>
          )}
          {personalInfo?.linkedin && (
            <span>{personalInfo.linkedin}</span>
          )}
        </div>
      </div>

      <div className="p-8">
        {/* Summary */}
        {personalInfo?.summary && (
          <section className="mb-10">
            <p className="text-slate-700 leading-relaxed text-justify">{personalInfo.summary}</p>
          </section>
        )}

        {/* Experience */}
        {experience.length > 0 && (
          <section className="mb-10">
            <h3 className="text-sm font-semibold text-slate-800 mb-6 uppercase tracking-widest">
              Experience
            </h3>
            
            {experience.map((exp, index) => (
              <div key={exp.id || index} className="mb-8">
                <div className="flex justify-between items-baseline mb-2">
                  <div>
                    <h4 className="text-base font-medium text-slate-800">{exp.jobTitle}</h4>
                    <p className="text-slate-600">{exp.company}</p>
                  </div>
                  <span className="text-sm text-slate-500">
                    {exp.startDate} — {exp.isCurrent ? "Present" : exp.endDate}
                  </span>
                </div>
                
                {exp.description && (
                  <p className="text-sm text-slate-700 mb-3 leading-relaxed">{exp.description}</p>
                )}
                
                {exp.achievements && exp.achievements.length > 0 && (
                  <ul className="text-sm text-slate-700 space-y-1">
                    {exp.achievements.map((achievement, i) => (
                      <li key={i} className="leading-relaxed">
                        — {achievement}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </section>
        )}

        {/* Education */}
        {education.length > 0 && (
          <section className="mb-10">
            <h3 className="text-sm font-semibold text-slate-800 mb-6 uppercase tracking-widest">
              Education
            </h3>
            
            {education.map((edu, index) => (
              <div key={edu.id || index} className="mb-6">
                <div className="flex justify-between items-baseline">
                  <div>
                    <h4 className="text-base font-medium text-slate-800">{edu.degree}</h4>
                    <p className="text-slate-600">{edu.institution}</p>
                    {edu.gpa && <p className="text-sm text-slate-600">GPA: {edu.gpa}</p>}
                  </div>
                  <span className="text-sm text-slate-500">
                    {edu.startDate} — {edu.endDate}
                  </span>
                </div>
                
                {edu.achievements && edu.achievements.length > 0 && (
                  <ul className="text-sm text-slate-700 space-y-1 mt-2">
                    {edu.achievements.map((achievement, i) => (
                      <li key={i}>— {achievement}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </section>
        )}

        {/* Skills */}
        {skills.length > 0 && (
          <section>
            <h3 className="text-sm font-semibold text-slate-800 mb-6 uppercase tracking-widest">
              Skills
            </h3>
            
            <div className="space-y-4">
              {skills.map((skillGroup, index) => (
                <div key={skillGroup.id || index}>
                  <h4 className="text-sm font-medium text-slate-700 mb-2">{skillGroup.category}</h4>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {skillGroup.skills.join(" • ")}
                  </p>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { FileText, HelpCircle } from "lucide-react";

export default function Header() {
  const [location] = useLocation();
  
  return (
    <nav className="bg-white border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/">
            <div className="flex items-center space-x-3 cursor-pointer">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <FileText className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold">TAC Resume Builder</h1>
                <p className="text-xs text-muted-foreground">AI-Powered Professional Resumes</p>
              </div>
            </div>
          </Link>
          
          <nav className="hidden md:flex space-x-8">
            <Link href="/#templates">
              <span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">
                Templates
              </span>
            </Link>
            <Link href="/#features">
              <span className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">
                Features
              </span>
            </Link>
          </nav>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm">
              <HelpCircle className="h-4 w-4" />
            </Button>
            {location === "/builder" ? (
              <Button onClick={() => window.print()}>
                Export Resume
              </Button>
            ) : (
              <Link href="/builder">
                <Button>Get Started</Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}

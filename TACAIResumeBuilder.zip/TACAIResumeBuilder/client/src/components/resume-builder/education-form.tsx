import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { educationSchema, type Education } from "@shared/schema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Trash2, Edit, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface EducationFormProps {
  data: Education[];
  onChange: (data: Education[]) => void;
}

export default function EducationForm({ data, onChange }: EducationFormProps) {
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [achievements, setAchievements] = useState<string[]>([]);
  const { toast } = useToast();

  const form = useForm<Education>({
    resolver: zodResolver(educationSchema),
    defaultValues: {
      degree: "",
      institution: "",
      location: "",
      startDate: "",
      endDate: "",
      gpa: "",
      achievements: [],
    },
  });

  const handleSubmit = (values: Education) => {
    const newData = [...data];
    values.achievements = achievements;
    
    if (editingIndex !== null) {
      newData[editingIndex] = values;
    } else {
      values.id = Date.now().toString();
      newData.push(values);
    }
    
    onChange(newData);
    handleCancel();
    toast({
      title: "Education saved",
      description: "Your education entry has been added to your resume.",
    });
  };

  const handleEdit = (index: number) => {
    const item = data[index];
    form.reset(item);
    setAchievements(item.achievements || []);
    setEditingIndex(index);
  };

  const handleDelete = (index: number) => {
    const newData = data.filter((_, i) => i !== index);
    onChange(newData);
    toast({
      title: "Education removed",
      description: "The education entry has been deleted.",
    });
  };

  const handleCancel = () => {
    form.reset({
      degree: "",
      institution: "",
      location: "",
      startDate: "",
      endDate: "",
      gpa: "",
      achievements: [],
    });
    setAchievements([]);
    setEditingIndex(null);
  };

  const addAchievement = () => {
    setAchievements([...achievements, ""]);
  };

  const updateAchievement = (index: number, value: string) => {
    const newAchievements = [...achievements];
    newAchievements[index] = value;
    setAchievements(newAchievements);
  };

  const removeAchievement = (index: number) => {
    const newAchievements = achievements.filter((_, i) => i !== index);
    setAchievements(newAchievements);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Education</h2>
        <Button
          type="button"
          variant="outline"
          onClick={() => setEditingIndex(data.length)}
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Education
        </Button>
      </div>

      {/* Education List */}
      <div className="space-y-4 mb-8">
        {data.map((education, index) => (
          <Card key={education.id || index}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h3 className="font-semibold">{education.degree}</h3>
                  <p className="text-sm text-muted-foreground">
                    {education.institution} • {education.startDate} - {education.endDate}
                  </p>
                  {education.gpa && (
                    <p className="text-sm text-muted-foreground">GPA: {education.gpa}</p>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEdit(index)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(index)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              {education.achievements && education.achievements.length > 0 && (
                <ul className="text-sm text-muted-foreground list-disc list-inside">
                  {education.achievements.slice(0, 2).map((achievement, i) => (
                    <li key={i}>{achievement}</li>
                  ))}
                  {education.achievements.length > 2 && (
                    <li>+{education.achievements.length - 2} more achievements</li>
                  )}
                </ul>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Education Form */}
      {editingIndex !== null && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold">
                {editingIndex < data.length ? "Edit Education" : "Add New Education"}
              </h3>
              <Button variant="ghost" size="sm" onClick={handleCancel}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="degree"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Degree</FormLabel>
                        <FormControl>
                          <Input placeholder="Bachelor of Science in Computer Science" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="institution"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Institution</FormLabel>
                        <FormControl>
                          <Input placeholder="University of California, Berkeley" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Start Date</FormLabel>
                        <FormControl>
                          <Input type="month" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Date</FormLabel>
                        <FormControl>
                          <Input type="month" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="gpa"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>GPA (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="3.8" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Location (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="Berkeley, CA" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Achievements Section */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <FormLabel>Achievements (Optional)</FormLabel>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addAchievement}
                    >
                      <Plus className="mr-1 h-3 w-3" />
                      Add Achievement
                    </Button>
                  </div>
                  
                  <div className="space-y-2">
                    {achievements.map((achievement, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <Input
                          placeholder="Dean's List, Magna Cum Laude, etc."
                          value={achievement}
                          onChange={(e) => updateAchievement(index, e.target.value)}
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeAchievement(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end space-x-4">
                  <Button type="button" variant="outline" onClick={handleCancel}>
                    Cancel
                  </Button>
                  <Button type="submit">
                    {editingIndex < data.length ? "Update Education" : "Add Education"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

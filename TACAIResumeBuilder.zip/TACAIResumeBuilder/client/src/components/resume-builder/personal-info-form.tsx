import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { personalInfoSchema, type PersonalInfo } from "@shared/schema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Wand2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface PersonalInfoFormProps {
  data: Partial<PersonalInfo>;
  onChange: (data: PersonalInfo) => void;
}

export default function PersonalInfoForm({ data, onChange }: PersonalInfoFormProps) {
  const { toast } = useToast();
  
  const form = useForm<PersonalInfo>({
    resolver: zodResolver(personalInfoSchema),
    defaultValues: {
      firstName: data.firstName || "",
      lastName: data.lastName || "",
      email: data.email || "",
      phone: data.phone || "",
      title: data.title || "",
      summary: data.summary || "",
      location: data.location || "",
      linkedin: data.linkedin || "",
      website: data.website || "",
    },
  });

  const enhanceSummaryMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/ai/generate", {
        type: "summary",
        context: {
          jobTitle: form.getValues("title"),
          currentContent: form.getValues("summary"),
        },
      });
      return response.json();
    },
    onSuccess: (data) => {
      form.setValue("summary", data.content);
      onChange(form.getValues());
      toast({
        title: "Summary enhanced",
        description: "AI has improved your professional summary.",
      });
    },
    onError: () => {
      toast({
        title: "Enhancement failed",
        description: "Unable to enhance summary. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFormChange = () => {
    const values = form.getValues();
    onChange(values);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Personal Information</h2>
        <div className="flex items-center space-x-2 text-purple-600">
          <Wand2 className="h-4 w-4" />
          <span className="text-sm font-medium">AI Assistant Active</span>
        </div>
      </div>

      <Form {...form}>
        <form className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="firstName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>First Name</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="John" 
                      {...field} 
                      onChange={(e) => {
                        field.onChange(e);
                        handleFormChange();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="lastName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Last Name</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Smith" 
                      {...field}
                      onChange={(e) => {
                        field.onChange(e);
                        handleFormChange();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Professional Title</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Input 
                      placeholder="Software Engineer" 
                      {...field}
                      onChange={(e) => {
                        field.onChange(e);
                        handleFormChange();
                      }}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 text-purple-600 hover:text-purple-700"
                    >
                      <Wand2 className="h-4 w-4" />
                    </Button>
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input 
                      type="email" 
                      placeholder="john.smith@email.com" 
                      {...field}
                      onChange={(e) => {
                        field.onChange(e);
                        handleFormChange();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone</FormLabel>
                  <FormControl>
                    <Input 
                      type="tel" 
                      placeholder="(555) 123-4567" 
                      {...field}
                      onChange={(e) => {
                        field.onChange(e);
                        handleFormChange();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Location</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="San Francisco, CA" 
                      {...field}
                      onChange={(e) => {
                        field.onChange(e);
                        handleFormChange();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="linkedin"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>LinkedIn</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="linkedin.com/in/johnsmith" 
                      {...field}
                      onChange={(e) => {
                        field.onChange(e);
                        handleFormChange();
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="summary"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Professional Summary</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Textarea 
                      rows={4}
                      placeholder="Write a brief professional summary..."
                      className="resize-none pr-24"
                      {...field}
                      onChange={(e) => {
                        field.onChange(e);
                        handleFormChange();
                      }}
                    />
                    <Button
                      type="button"
                      size="sm"
                      className="absolute top-3 right-3 bg-purple-600 hover:bg-purple-700"
                      onClick={() => enhanceSummaryMutation.mutate()}
                      disabled={enhanceSummaryMutation.isPending}
                    >
                      <Wand2 className="mr-1 h-3 w-3" />
                      {enhanceSummaryMutation.isPending ? "Generating..." : "AI Generate"}
                    </Button>
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </form>
      </Form>
    </div>
  );
}

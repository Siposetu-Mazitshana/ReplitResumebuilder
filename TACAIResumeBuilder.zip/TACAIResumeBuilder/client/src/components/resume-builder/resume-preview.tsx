import { useState } from "react";
import { type ResumeData } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ModernTemplate from "@/components/templates/modern-template";
import ClassicTemplate from "@/components/templates/classic-template";
import CreativeTemplate from "@/components/templates/creative-template";
import ExecutiveTemplate from "@/components/templates/executive-template";
import TechnicalTemplate from "@/components/templates/technical-template";
import MinimalTemplate from "@/components/templates/minimal-template";
import { Eye, Download, Palette, ZoomIn, FileText } from "lucide-react";
import { exportToPDF, exportToHTML, exportToDOCX } from "@/lib/pdf-export";
import { useToast } from "@/hooks/use-toast";

interface ResumePreviewProps {
  data: ResumeData;
  template: string;
  onTemplateChange: (template: string) => void;
}

export default function ResumePreview({ data, template, onTemplateChange }: ResumePreviewProps) {
  const [isFullView, setIsFullView] = useState(false);
  const { toast } = useToast();

  const renderTemplate = () => {
    switch (template) {
      case "classic":
        return <ClassicTemplate data={data} />;
      case "creative":
        return <CreativeTemplate data={data} />;
      case "executive":
        return <ExecutiveTemplate data={data} />;
      case "technical":
        return <TechnicalTemplate data={data} />;
      case "minimal":
        return <MinimalTemplate data={data} />;
      case "modern":
      default:
        return <ModernTemplate data={data} />;
    }
  };

  const handleExport = async () => {
    try {
      await exportToPDF(data, template);
      toast({
        title: "Resume exported",
        description: "Your resume has been downloaded as a PDF.",
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Unable to export resume. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isFullView) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b">
            <h3 className="text-lg font-semibold">Resume Preview</h3>
            <div className="flex items-center space-x-2">
              <Button onClick={handleExport}>
                <Download className="mr-2 h-4 w-4" />
                Export PDF
              </Button>
              <Button variant="outline" onClick={() => setIsFullView(false)}>
                Close
              </Button>
            </div>
          </div>
          <div className="overflow-auto max-h-[calc(90vh-80px)]">
            <div className="p-8 bg-gray-50">
              <div className="bg-white shadow-lg mx-auto" style={{ width: "8.5in", minHeight: "11in" }}>
                {renderTemplate()}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Preview Controls */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Live Preview</h3>
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm" onClick={() => setIsFullView(true)}>
                <ZoomIn className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Palette className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">Template:</span>
              <Select value={template} onValueChange={onTemplateChange}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="modern">Modern</SelectItem>
                  <SelectItem value="classic">Classic</SelectItem>
                  <SelectItem value="creative">Creative</SelectItem>
                  <SelectItem value="executive">Executive</SelectItem>
                  <SelectItem value="technical">Technical</SelectItem>
                  <SelectItem value="minimal">Minimal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center space-x-2">
              <Badge variant="secondary" className="bg-green-100 text-green-700">
                <Eye className="mr-1 h-3 w-3" />
                ATS Ready
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Mini Preview */}
      <Card>
        <CardContent className="p-4">
          <div 
            className="bg-white border rounded-lg overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
            style={{ 
              transform: "scale(0.3)", 
              transformOrigin: "top left",
              width: "8.5in",
              height: "11in",
              marginBottom: "-7.7in",
              marginRight: "-5.95in"
            }}
            onClick={() => setIsFullView(true)}
          >
            {renderTemplate()}
          </div>
        </CardContent>
      </Card>

      {/* Template Quick Switch */}
      <Card>
        <CardContent className="p-4">
          <h4 className="font-semibold mb-3">Quick Template Switch</h4>
          <div className="grid grid-cols-3 gap-2">
            <Button
              variant={template === "modern" ? "default" : "outline"}
              size="sm"
              onClick={() => onTemplateChange("modern")}
              className="h-16 flex flex-col p-2"
            >
              <div className="w-full h-6 bg-primary rounded mb-1"></div>
              <span className="text-xs">Modern</span>
            </Button>
            
            <Button
              variant={template === "classic" ? "default" : "outline"}
              size="sm"
              onClick={() => onTemplateChange("classic")}
              className="h-16 flex flex-col p-2"
            >
              <div className="w-full h-6 bg-slate-600 rounded mb-1"></div>
              <span className="text-xs">Classic</span>
            </Button>

            <Button
              variant={template === "creative" ? "default" : "outline"}
              size="sm"
              onClick={() => onTemplateChange("creative")}
              className="h-16 flex flex-col p-2"
            >
              <div className="w-full h-6 bg-gradient-to-r from-purple-500 to-blue-500 rounded mb-1"></div>
              <span className="text-xs">Creative</span>
            </Button>

            <Button
              variant={template === "executive" ? "default" : "outline"}
              size="sm"
              onClick={() => onTemplateChange("executive")}
              className="h-16 flex flex-col p-2"
            >
              <div className="w-full h-6 bg-slate-800 rounded mb-1"></div>
              <span className="text-xs">Executive</span>
            </Button>

            <Button
              variant={template === "technical" ? "default" : "outline"}
              size="sm"
              onClick={() => onTemplateChange("technical")}
              className="h-16 flex flex-col p-2"
            >
              <div className="w-full h-6 bg-green-600 rounded mb-1"></div>
              <span className="text-xs">Technical</span>
            </Button>

            <Button
              variant={template === "minimal" ? "default" : "outline"}
              size="sm"
              onClick={() => onTemplateChange("minimal")}
              className="h-16 flex flex-col p-2"
            >
              <div className="w-full h-6 bg-gray-400 rounded mb-1"></div>
              <span className="text-xs">Minimal</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Export Actions */}
      <Card>
        <CardContent className="p-4">
          <h4 className="font-semibold mb-3">Export Options</h4>
          <div className="space-y-2">
            <Button onClick={handleExport} className="w-full">
              <Download className="mr-2 h-4 w-4" />
              Export as PDF
            </Button>
            <Button 
              variant="outline" 
              onClick={async () => {
                try {
                  await exportToDOCX(data, template);
                  toast({
                    title: "Resume exported",
                    description: "Your resume has been downloaded as a Word document.",
                  });
                } catch (error) {
                  toast({
                    title: "Export failed",
                    description: "Unable to export resume. Please try again.",
                    variant: "destructive",
                  });
                }
              }} 
              className="w-full"
            >
              <FileText className="mr-2 h-4 w-4" />
              Export as DOCX
            </Button>
            <Button 
              variant="outline" 
              onClick={async () => {
                try {
                  await exportToHTML(data, template);
                  toast({
                    title: "Resume exported",
                    description: "Your resume has been downloaded as an HTML file.",
                  });
                } catch (error) {
                  toast({
                    title: "Export failed",
                    description: "Unable to export resume. Please try again.",
                    variant: "destructive",
                  });
                }
              }} 
              className="w-full"
            >
              <Download className="mr-2 h-4 w-4" />
              Export as HTML
            </Button>
          </div>
          <p className="text-xs text-muted-foreground text-center mt-3">
            Choose your preferred format for downloading
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

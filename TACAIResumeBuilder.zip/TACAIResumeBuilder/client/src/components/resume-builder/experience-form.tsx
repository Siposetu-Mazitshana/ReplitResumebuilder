import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { experienceSchema, type Experience } from "@shared/schema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Edit, Wand2, X } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ExperienceFormProps {
  data: Experience[];
  onChange: (data: Experience[]) => void;
}

export default function ExperienceForm({ data, onChange }: ExperienceFormProps) {
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [achievements, setAchievements] = useState<string[]>([]);
  const { toast } = useToast();

  const form = useForm<Experience>({
    resolver: zodResolver(experienceSchema),
    defaultValues: {
      jobTitle: "",
      company: "",
      location: "",
      startDate: "",
      endDate: "",
      isCurrent: false,
      description: "",
      achievements: [],
    },
  });

  const enhanceDescriptionMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/ai/generate", {
        type: "description",
        context: {
          jobTitle: form.getValues("jobTitle"),
          currentContent: form.getValues("description"),
        },
      });
      return response.json();
    },
    onSuccess: (data) => {
      form.setValue("description", data.content);
      toast({
        title: "Description enhanced",
        description: "AI has improved your job description.",
      });
    },
  });

  const generateAchievementsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/ai/generate", {
        type: "achievements",
        context: {
          jobTitle: form.getValues("jobTitle"),
        },
      });
      return response.json();
    },
    onSuccess: (data) => {
      try {
        const achievements = JSON.parse(data.content);
        if (Array.isArray(achievements)) {
          setAchievements(achievements);
          form.setValue("achievements", achievements);
        }
      } catch (error) {
        console.error("Failed to parse achievements:", error);
      }
      toast({
        title: "Achievements generated",
        description: "AI has created professional achievement statements.",
      });
    },
  });

  const handleSubmit = (values: Experience) => {
    const newData = [...data];
    values.achievements = achievements;
    
    if (editingIndex !== null) {
      newData[editingIndex] = values;
    } else {
      values.id = Date.now().toString();
      newData.push(values);
    }
    
    onChange(newData);
    handleCancel();
    toast({
      title: "Experience saved",
      description: "Your work experience has been added to your resume.",
    });
  };

  const handleEdit = (index: number) => {
    const item = data[index];
    form.reset(item);
    setAchievements(item.achievements || []);
    setEditingIndex(index);
  };

  const handleDelete = (index: number) => {
    const newData = data.filter((_, i) => i !== index);
    onChange(newData);
    toast({
      title: "Experience removed",
      description: "The experience entry has been deleted.",
    });
  };

  const handleCancel = () => {
    form.reset({
      jobTitle: "",
      company: "",
      location: "",
      startDate: "",
      endDate: "",
      isCurrent: false,
      description: "",
      achievements: [],
    });
    setAchievements([]);
    setEditingIndex(null);
  };

  const addAchievement = () => {
    setAchievements([...achievements, ""]);
  };

  const updateAchievement = (index: number, value: string) => {
    const newAchievements = [...achievements];
    newAchievements[index] = value;
    setAchievements(newAchievements);
    form.setValue("achievements", newAchievements);
  };

  const removeAchievement = (index: number) => {
    const newAchievements = achievements.filter((_, i) => i !== index);
    setAchievements(newAchievements);
    form.setValue("achievements", newAchievements);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Work Experience</h2>
        <Button
          type="button"
          variant="outline"
          onClick={() => setEditingIndex(data.length)}
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Experience
        </Button>
      </div>

      {/* Experience List */}
      <div className="space-y-4 mb-8">
        {data.map((experience, index) => (
          <Card key={experience.id || index}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h3 className="font-semibold">{experience.jobTitle}</h3>
                  <p className="text-sm text-muted-foreground">
                    {experience.company} • {experience.startDate} - {experience.isCurrent ? "Present" : experience.endDate}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEdit(index)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(index)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <p className="text-sm text-muted-foreground line-clamp-2">
                {experience.description}
              </p>
              {experience.achievements && experience.achievements.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {experience.achievements.slice(0, 2).map((achievement, i) => (
                    <Badge key={i} variant="secondary" className="text-xs">
                      {achievement.substring(0, 30)}...
                    </Badge>
                  ))}
                  {experience.achievements.length > 2 && (
                    <Badge variant="secondary" className="text-xs">
                      +{experience.achievements.length - 2} more
                    </Badge>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Experience Form */}
      {editingIndex !== null && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold">
                {editingIndex < data.length ? "Edit Experience" : "Add New Experience"}
              </h3>
              <Button variant="ghost" size="sm" onClick={handleCancel}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="jobTitle"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Job Title</FormLabel>
                        <FormControl>
                          <Input placeholder="Senior Software Engineer" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="company"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company</FormLabel>
                        <FormControl>
                          <Input placeholder="TechCorp Solutions" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-6">
                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Start Date</FormLabel>
                        <FormControl>
                          <Input type="month" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Date</FormLabel>
                        <FormControl>
                          <Input 
                            type="month" 
                            disabled={form.watch("isCurrent")}
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="isCurrent"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center space-x-2 space-y-0 pt-6">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="text-sm font-normal">
                          Current Position
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between">
                        <FormLabel>Job Description</FormLabel>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => enhanceDescriptionMutation.mutate()}
                          disabled={enhanceDescriptionMutation.isPending}
                        >
                          <Wand2 className="mr-1 h-3 w-3" />
                          {enhanceDescriptionMutation.isPending ? "Enhancing..." : "Enhance with AI"}
                        </Button>
                      </div>
                      <FormControl>
                        <Textarea
                          rows={4}
                          placeholder="Describe your key responsibilities and achievements..."
                          className="resize-none"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Achievements Section */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <FormLabel>Key Achievements</FormLabel>
                    <div className="flex space-x-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => generateAchievementsMutation.mutate()}
                        disabled={generateAchievementsMutation.isPending}
                      >
                        <Wand2 className="mr-1 h-3 w-3" />
                        {generateAchievementsMutation.isPending ? "Generating..." : "AI Generate"}
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={addAchievement}
                      >
                        <Plus className="mr-1 h-3 w-3" />
                        Add Achievement
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    {achievements.map((achievement, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <Input
                          placeholder="Describe a key achievement..."
                          value={achievement}
                          onChange={(e) => updateAchievement(index, e.target.value)}
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => removeAchievement(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex justify-end space-x-4">
                  <Button type="button" variant="outline" onClick={handleCancel}>
                    Cancel
                  </Button>
                  <Button type="submit">
                    {editingIndex < data.length ? "Update Experience" : "Add Experience"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

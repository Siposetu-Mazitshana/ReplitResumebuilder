import { useMutation } from "@tanstack/react-query";
import { type ResumeData } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, Wand2, CheckCircle, Target, TrendingUp } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AISuggestionsProps {
  currentStep: number;
  resumeData: ResumeData;
  onApplySuggestion: (field: string, value: any) => void;
}

export default function AISuggestions({ currentStep, resumeData, onApplySuggestion }: AISuggestionsProps) {
  const { toast } = useToast();

  const generateSuggestionMutation = useMutation({
    mutationFn: async (type: string) => {
      const response = await apiRequest("POST", "/api/ai/generate", {
        type,
        context: {
          jobTitle: resumeData.personalInfo?.title,
          currentContent: type === "summary" ? resumeData.personalInfo?.summary : "",
        },
      });
      return response.json();
    },
    onSuccess: (data, type) => {
      toast({
        title: "AI suggestion generated",
        description: "New content suggestion is ready for review.",
      });
    },
  });

  const getSuggestions = () => {
    switch (currentStep) {
      case 1:
        return [
          {
            icon: Target,
            title: "Optimize Your Title",
            description: "Consider adding seniority level or specialization to your professional title",
            action: "Generate Title",
            type: "title",
          },
          {
            icon: TrendingUp,
            title: "Enhance Summary",
            description: "Add quantifiable achievements and industry-specific keywords",
            action: "Generate Summary",
            type: "summary",
          },
        ];
      case 2:
        return [
          {
            icon: Target,
            title: "Quantify Achievements",
            description: "Add numbers, percentages, and metrics to your accomplishments",
            action: "Add Metrics",
            type: "achievements",
          },
          {
            icon: CheckCircle,
            title: "ATS Keywords",
            description: "Include industry-relevant keywords for better ATS scanning",
            action: "Add Keywords",
            type: "keywords",
          },
        ];
      case 3:
        return [
          {
            icon: TrendingUp,
            title: "Highlight Honors",
            description: "Add academic achievements like Dean's List, honors, or relevant coursework",
            action: "Add Honors",
            type: "honors",
          },
        ];
      case 4:
        return [
          {
            icon: Target,
            title: "Skill Categories",
            description: "Organize skills into clear categories for better readability",
            action: "Organize Skills",
            type: "skills",
          },
          {
            icon: TrendingUp,
            title: "Industry Skills",
            description: "Add trending skills relevant to your target industry",
            action: "Add Trending",
            type: "trending-skills",
          },
        ];
      default:
        return [];
    }
  };

  const suggestions = getSuggestions();

  if (suggestions.length === 0) {
    return (
      <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
        <CardContent className="p-6">
          <div className="flex items-center mb-4">
            <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
            <h3 className="font-semibold text-green-700">Great Progress!</h3>
          </div>
          <p className="text-sm text-muted-foreground">
            You're doing well. Review your resume and make final adjustments before exporting.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center mr-3">
            <Lightbulb className="h-4 w-4 text-purple-600" />
          </div>
          <div>
            <h3 className="font-semibold text-purple-800">AI Suggestions</h3>
            <p className="text-sm text-purple-600">Smart recommendations for this section</p>
          </div>
        </div>
        
        <div className="space-y-4">
          {suggestions.map((suggestion, index) => (
            <div key={index} className="bg-white/60 rounded-lg p-4 border border-purple-100">
              <div className="flex items-start space-x-3">
                <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <suggestion.icon className="h-3 w-3 text-purple-600" />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-purple-900 mb-1">{suggestion.title}</h4>
                  <p className="text-sm text-purple-700 mb-3">{suggestion.description}</p>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-purple-200 text-purple-700 hover:bg-purple-50"
                    onClick={() => generateSuggestionMutation.mutate(suggestion.type)}
                    disabled={generateSuggestionMutation.isPending}
                  >
                    <Wand2 className="mr-1 h-3 w-3" />
                    {generateSuggestionMutation.isPending ? "Generating..." : suggestion.action}
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t border-purple-200">
          <div className="flex items-center justify-between text-sm">
            <span className="text-purple-700">💡 Pro tip: Use specific metrics and industry keywords</span>
            <Badge variant="secondary" className="bg-purple-100 text-purple-700">
              AI Powered
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, X } from "lucide-react";

interface TemplateSelectorProps {
  currentTemplate: string;
  onSelectTemplate: (template: string) => void;
  onClose: () => void;
}

const templates = [
  {
    id: "modern",
    name: "Modern Professional",
    description: "Clean, contemporary design perfect for tech and creative industries",
    preview: "bg-primary",
    features: ["ATS Optimized", "Clean Layout", "Professional"],
  },
  {
    id: "classic",
    name: "Executive Classic",
    description: "Traditional layout ideal for senior positions and conservative industries",
    preview: "bg-slate-600",
    features: ["Traditional", "Executive Style", "Conservative"],
  },
  {
    id: "creative",
    name: "Creative Minimal",
    description: "Stylish design that balances creativity with professionalism",
    preview: "bg-purple-500",
    features: ["Creative", "Modern", "Minimal"],
  },
];

export default function TemplateSelector({ currentTemplate, onSelectTemplate, onClose }: TemplateSelectorProps) {
  const [selectedTemplate, setSelectedTemplate] = useState(currentTemplate);

  const handleApply = () => {
    onSelectTemplate(selectedTemplate);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-semibold">Choose Your Template</h3>
              <p className="text-muted-foreground mt-1">Select a professional template that matches your style</p>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {templates.map((template) => (
              <Card 
                key={template.id}
                className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                  selectedTemplate === template.id 
                    ? "ring-2 ring-primary border-primary" 
                    : "hover:border-primary/50"
                }`}
                onClick={() => setSelectedTemplate(template.id)}
              >
                <div className="aspect-[3/4] bg-muted p-4">
                  <div className="w-full h-full bg-white rounded-md shadow-sm flex items-center justify-center relative overflow-hidden">
                    {/* Template Preview Mockup */}
                    <div className="text-center w-full p-2">
                      <div className={`h-3 ${template.preview} rounded w-3/4 mx-auto mb-2`}></div>
                      <div className="h-1 bg-muted-foreground/30 rounded w-1/2 mx-auto mb-3"></div>
                      <div className="space-y-1">
                        <div className="h-1 bg-muted-foreground/20 rounded"></div>
                        <div className="h-1 bg-muted-foreground/20 rounded w-5/6 mx-auto"></div>
                        <div className="h-1 bg-muted-foreground/20 rounded w-3/4 mx-auto"></div>
                      </div>
                    </div>
                    
                    {selectedTemplate === template.id && (
                      <div className="absolute top-2 right-2">
                        <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                          <CheckCircle className="h-4 w-4 text-white" />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <CardContent className="p-4">
                  <h4 className="font-semibold mb-1">{template.name}</h4>
                  <p className="text-sm text-muted-foreground mb-3">{template.description}</p>
                  
                  <div className="flex flex-wrap gap-1">
                    {template.features.map((feature) => (
                      <Badge key={feature} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="flex justify-end mt-6 pt-6 border-t border-border">
            <div className="flex space-x-3">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button onClick={handleApply}>
                Apply Template
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

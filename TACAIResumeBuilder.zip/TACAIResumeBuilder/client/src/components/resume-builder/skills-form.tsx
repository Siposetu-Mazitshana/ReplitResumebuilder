import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { skillSchema, type Skill } from "@shared/schema";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Edit, X, Wand2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SkillsFormProps {
  data: Skill[];
  onChange: (data: Skill[]) => void;
}

export default function SkillsForm({ data, onChange }: SkillsFormProps) {
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [skillsList, setSkillsList] = useState<string[]>([]);
  const [currentSkill, setCurrentSkill] = useState("");
  const { toast } = useToast();

  const form = useForm<Skill>({
    resolver: zodResolver(skillSchema),
    defaultValues: {
      category: "",
      skills: [],
    },
  });

  const generateSkillsMutation = useMutation({
    mutationFn: async (category: string) => {
      const response = await apiRequest("POST", "/api/ai/generate", {
        type: "skills",
        context: {
          jobTitle: category,
        },
      });
      return response.json();
    },
    onSuccess: (data) => {
      try {
        const skills = JSON.parse(data.content);
        const category = form.getValues("category");
        
        if (skills[category]) {
          setSkillsList(skills[category]);
          form.setValue("skills", skills[category]);
        } else {
          // If exact category not found, use the first available category
          const firstCategory = Object.keys(skills)[0];
          if (skills[firstCategory]) {
            setSkillsList(skills[firstCategory]);
            form.setValue("skills", skills[firstCategory]);
          }
        }
      } catch (error) {
        console.error("Failed to parse skills:", error);
      }
      toast({
        title: "Skills generated",
        description: "AI has created relevant skills for this category.",
      });
    },
  });

  const handleSubmit = (values: Skill) => {
    const newData = [...data];
    values.skills = skillsList;
    
    if (editingIndex !== null) {
      newData[editingIndex] = values;
    } else {
      values.id = Date.now().toString();
      newData.push(values);
    }
    
    onChange(newData);
    handleCancel();
    toast({
      title: "Skills saved",
      description: "Your skill category has been added to your resume.",
    });
  };

  const handleEdit = (index: number) => {
    const item = data[index];
    form.reset(item);
    setSkillsList(item.skills || []);
    setEditingIndex(index);
  };

  const handleDelete = (index: number) => {
    const newData = data.filter((_, i) => i !== index);
    onChange(newData);
    toast({
      title: "Skills removed",
      description: "The skill category has been deleted.",
    });
  };

  const handleCancel = () => {
    form.reset({
      category: "",
      skills: [],
    });
    setSkillsList([]);
    setCurrentSkill("");
    setEditingIndex(null);
  };

  const addSkill = () => {
    if (currentSkill.trim() && !skillsList.includes(currentSkill.trim())) {
      const newSkills = [...skillsList, currentSkill.trim()];
      setSkillsList(newSkills);
      form.setValue("skills", newSkills);
      setCurrentSkill("");
    }
  };

  const removeSkill = (skillToRemove: string) => {
    const newSkills = skillsList.filter(skill => skill !== skillToRemove);
    setSkillsList(newSkills);
    form.setValue("skills", newSkills);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addSkill();
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Skills</h2>
        <Button
          type="button"
          variant="outline"
          onClick={() => setEditingIndex(data.length)}
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Skill Category
        </Button>
      </div>

      {/* Skills List */}
      <div className="space-y-4 mb-8">
        {data.map((skillGroup, index) => (
          <Card key={skillGroup.id || index}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold">{skillGroup.category}</h3>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEdit(index)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(index)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {skillGroup.skills.map((skill, skillIndex) => (
                  <Badge key={skillIndex} variant="secondary">
                    {skill}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Skills Form */}
      {editingIndex !== null && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold">
                {editingIndex < data.length ? "Edit Skill Category" : "Add New Skill Category"}
              </h3>
              <Button variant="ghost" size="sm" onClick={handleCancel}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between">
                        <FormLabel>Category Name</FormLabel>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => generateSkillsMutation.mutate(field.value)}
                          disabled={!field.value || generateSkillsMutation.isPending}
                        >
                          <Wand2 className="mr-1 h-3 w-3" />
                          {generateSkillsMutation.isPending ? "Generating..." : "Generate with AI"}
                        </Button>
                      </div>
                      <FormControl>
                        <Input 
                          placeholder="e.g., Technical Skills, Programming Languages, Soft Skills" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <FormLabel>Skills</FormLabel>
                  <div className="space-y-3 mt-2">
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Type a skill and press Enter"
                        value={currentSkill}
                        onChange={(e) => setCurrentSkill(e.target.value)}
                        onKeyPress={handleKeyPress}
                      />
                      <Button type="button" onClick={addSkill}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    {skillsList.length > 0 && (
                      <div className="flex flex-wrap gap-2 p-3 bg-muted rounded-lg">
                        {skillsList.map((skill, index) => (
                          <Badge 
                            key={index} 
                            variant="secondary" 
                            className="cursor-pointer hover:bg-destructive hover:text-destructive-foreground transition-colors"
                            onClick={() => removeSkill(skill)}
                          >
                            {skill}
                            <X className="ml-1 h-3 w-3" />
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex justify-end space-x-4">
                  <Button type="button" variant="outline" onClick={handleCancel}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={skillsList.length === 0}>
                    {editingIndex < data.length ? "Update Skills" : "Add Skills"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
